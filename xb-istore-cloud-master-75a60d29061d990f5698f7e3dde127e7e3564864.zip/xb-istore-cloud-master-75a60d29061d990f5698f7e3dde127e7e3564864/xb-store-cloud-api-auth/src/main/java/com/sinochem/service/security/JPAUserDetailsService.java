package com.sinochem.service.security;

import com.sinochem.vo.AuthUser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 */
@Service
public class JPAUserDetailsService implements UserDetailsService {

    @Value("${auth.username}")
    private String userName;

    @Value("${auth.password}")
    private String password;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AuthUser user = new AuthUser();
        if (userName.equals(username)) {
            user.setUsername(userName);
            user.setPassword(password);
        } else {
            throw new UsernameNotFoundException(username);
        }
        return user;
    }
}
