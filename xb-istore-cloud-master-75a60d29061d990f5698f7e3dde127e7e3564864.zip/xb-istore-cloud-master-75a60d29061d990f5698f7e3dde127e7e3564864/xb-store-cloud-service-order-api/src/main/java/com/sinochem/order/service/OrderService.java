package com.sinochem.order.service;


import com.sinochem.order.service.hystrix.OrderServiceHystrix;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbResult;
import com.sinochem.pojo.vo.OrderQuery;
import com.sinochem.pojo.vo.UserCart;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 订单相关操作 Service
 *
 * @author liuming
 * @create
 */
@FeignClient(value = "xb-store-cloud-service-order", fallback = OrderServiceHystrix.class)
public interface OrderService {
    /**
     * 提交订单
     *
     * @param userCart 封装的用户购物车信息
     * @return
     */
    @RequestMapping(value = "/generateOrder", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    XbResult generateOrder(@RequestBody UserCart userCart);

    /**
     * 查询订单列表
     *
     * @param orderQuery
     * @return
     */
    @RequestMapping(value = "/findOrderList", method = RequestMethod.POST)
    XbResult findOrderList(@RequestBody OrderQuery orderQuery);

    /**
     * 更新orderNo订单支付状态
     *
     * @param xbOrder
     * @return
     */
    @RequestMapping(value = "/updateOrderPayByOrderNo", method = RequestMethod.POST)
    XbResult updateOrderPayByOrderNo(@RequestBody XbOrder xbOrder);

    /**
     * 删除orderNo订单
     *
     * @param orderQuery
     * @return
     */
    @RequestMapping(value = "/cancelOrderPayByOrderNo", method = RequestMethod.POST)
    XbResult cancelOrderPayByOrderNo(@RequestBody OrderQuery orderQuery);
}