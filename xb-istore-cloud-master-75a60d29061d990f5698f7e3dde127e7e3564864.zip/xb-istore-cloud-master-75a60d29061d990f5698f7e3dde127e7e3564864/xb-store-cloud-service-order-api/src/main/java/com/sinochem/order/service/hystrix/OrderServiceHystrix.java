package com.sinochem.order.service.hystrix;

import com.sinochem.order.service.OrderService;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbResult;
import com.sinochem.pojo.vo.OrderQuery;
import com.sinochem.pojo.vo.UserCart;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 订单服务 熔断处理
 *
 * @author liuming
 * @create
 */

@Component
public class OrderServiceHystrix implements OrderService {


    /**
     * 提交订单
     *
     * @param userCart 封装的用户购物车信息
     * @return
     */
    @Override
    public XbResult generateOrder(@RequestBody UserCart userCart) {
        return null;
    }

    @Override
    public XbResult findOrderList(@RequestBody OrderQuery orderQuery) {
        return null;
    }

    @Override
    public XbResult updateOrderPayByOrderNo(@RequestBody XbOrder xbOrder) {
        return null;
    }

    @Override
    public XbResult cancelOrderPayByOrderNo(@RequestBody OrderQuery orderQuery) {
        return null;
    }
}

