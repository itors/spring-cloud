package com.sinochem.order.listener;

import com.sinochem.mapper.XbOrderMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

@Component
public class EventSubscriber implements DisposableBean, Runnable {

    private static final Logger logger = LoggerFactory.getLogger(EventSubscriber.class);

    private Thread thread;
    //
    @Autowired
    private XbOrderMapper xbOrderMapper;


    public EventSubscriber() {
        this.thread = new Thread(this, "O_ORDER_CLEANER");
        this.thread.start();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public void run() {
        logger.info("====================EventSubscriber Start...===============");
        Jedis jedis = RedisClient.jedisPool.getResource();
        jedis.psubscribe(new OrderExpiredListener(xbOrderMapper), "__keyevent@*__:expired");
    }

    @Override
    public void destroy() {
        this.thread.interrupt();
    }

}