package com.sinochem.order.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.sinochem.enums.OrderStatusEnum;
import com.sinochem.enums.PayChannelEnum;
import com.sinochem.mapper.XbGoodsDeptMapper;
import com.sinochem.mapper.XbOrderDetailMapper;
import com.sinochem.mapper.XbOrderMapper;
import com.sinochem.order.service.OrderService;
import com.sinochem.pojo.XbGoodsDept;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.XbOrderExample;
import com.sinochem.pojo.XbResult;
import com.sinochem.pojo.vo.CartItem;
import com.sinochem.pojo.vo.OrderQuery;
import com.sinochem.pojo.vo.UserCart;
import com.sinochem.pojo.vo.UserOrder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * order操作实现
 *
 * @author liuming
 * @create
 */
@Api(value = "API - OrderServiceImpl", description = "order 服务")
@RestController
@RefreshScope
public class OrderServiceImpl implements OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private RedissonClient redissonClient;

    @Autowired
    private XbOrderMapper xbOrderMapper;

    @Autowired
    private XbGoodsDeptMapper xbGoodsDeptMapper;

    @Autowired
    private XbOrderDetailMapper xbOrderDetailMapper;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${idgenerator.server}")
    private String idGeneratorServer;

    @ApiOperation("生成订单")
    @ApiResponses(
            {
                    @ApiResponse(code = 200, message = "Successful — 请求已完成"),
                    @ApiResponse(code = 400, message = "请求中有语法问题，或不能满足请求"),
                    @ApiResponse(code = 401, message = "未授权客户机访问数据"),
                    @ApiResponse(code = 404, message = "服务器找不到给定的资源；文档不存在"),
                    @ApiResponse(code = 500, message = "服务器不能完成请求")
            }
    )
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public XbResult generateOrder(@RequestBody UserCart userCart) {
        //判空
        if (userCart == null) {
            return XbResult.build(400, 400, "参数不能为空");
        }
        //判会话是否有效
        String sessionId = userCart.getSessionId();
        Object wxSessionObj = null;
        if (StringUtils.isEmpty(sessionId)) {
            logger.error("没有用户信息!");
            return XbResult.build(400, 400, "没有用户信息!");
        } else {
            //从缓存中获取session_key
            RBucket<String> userBucket = redissonClient.getBucket(sessionId);
            wxSessionObj = userBucket.get();
            if (null == wxSessionObj) {
                return XbResult.build(400, 40008, "session不存在");
            }
        }
        if (wxSessionObj == null) {
            return XbResult.build(400, 40008, "session不存在");
        }

        String openId = wxSessionObj.toString().split("#")[1];

        List<CartItem> cartItemList = userCart.getCartItemList();
        Long shopNo = userCart.getShopNo();
        // 保存订单项️
        if (cartItemList.size() > 0) {
            //TODO to id generator api
            String orderNo = restTemplate.getForObject(idGeneratorServer, long.class).toString();
            List<XbOrderDetail> xbOrderDetailList = Lists.newArrayList();
            XbOrder xbOrder = new XbOrder();

            BigDecimal goodsAmountTotal = new BigDecimal(0);
            Integer goodsCountTotal = new Integer(0);
            for (int i = 0; i < cartItemList.size(); i++) {
                CartItem cartItem = cartItemList.get(i);
                XbGoodsDept goodsDept = new XbGoodsDept();
                goodsDept.setBarCode(cartItem.getBarCode());
                goodsDept.setShopNo(shopNo);
                goodsDept = xbGoodsDeptMapper.selectGoodsByBarCode(goodsDept);

                if (goodsDept == null) {
                    logger.info("按shopNo:{}-goodCode:{} 未查询到信息！", shopNo, cartItem.getGoodsCode());
                    throw new RuntimeException("商品信息不匹配");
                }

                XbOrderDetail xbOrderDetail = new XbOrderDetail();
                xbOrderDetail.setBarCode(cartItem.getBarCode());
                xbOrderDetail.setBrandName(goodsDept.getXbGoods().getBrandName());
                xbOrderDetail.setGoodsAmount(goodsDept.getSalePrice().multiply(new BigDecimal(cartItem.getGoodsCount())));
                xbOrderDetail.setGoodsCountD(cartItem.getGoodsCount());
                xbOrderDetail.setGoodsCode(cartItem.getGoodsCode());
                xbOrderDetail.setGoodsName(goodsDept.getXbGoods().getGoodsName());
                xbOrderDetail.setOriginPlace(goodsDept.getXbGoods().getOriginPlace());
                xbOrderDetail.setPicUrl(StringUtils.isEmpty(goodsDept.getPicUrl()) ? goodsDept.getXbGoods().getMainPicUrl() : goodsDept.getPicUrl());
                xbOrderDetail.setSaleDepartment(goodsDept.getSaleDepartment());
                xbOrderDetail.setSalePrice(goodsDept.getSalePrice());
                xbOrderDetail.setSaleTaxRate(goodsDept.getSaleTaxRate());
                xbOrderDetail.setSapStock(goodsDept.getXbGoods().getSapStock());
                xbOrderDetail.setShortGoodsName(goodsDept.getXbGoods().getShortGoodsName());
                xbOrderDetail.setOrderNo(orderNo);
                xbOrderDetail.setCategoryType(goodsDept.getXbGoods().getCategoryType());
                xbOrderDetailList.add(xbOrderDetail);
                //商品总价
                goodsAmountTotal = goodsAmountTotal.add(xbOrderDetail.getGoodsAmount());
                //商品总数
                goodsCountTotal = goodsCountTotal + xbOrderDetail.getGoodsCountD();
            }
            //判断如果没有订单详情则生成订单事务失败
            if (CollectionUtils.isEmpty(xbOrderDetailList)) {
                return XbResult.build(400, 40010, "生成订单失败，可能是传入的参数barcode shopno goodscode不匹配");
            }

            xbOrder.setGoodsAmountTotal(goodsAmountTotal);
            xbOrder.setGoodsCount(goodsCountTotal);
            //TODO 总折扣金额
            xbOrder.setDiscAmountTotal(new BigDecimal(0));
            xbOrder.setOpenId(openId);
            xbOrder.setOrderAmountTotal(goodsAmountTotal);
            xbOrder.setOrderDetailList(xbOrderDetailList);
            xbOrder.setPayChannel(Byte.valueOf(userCart.getPaymentType() + ""));

            xbOrder.setOrderNo(orderNo);
            xbOrder.setOrderStatus(Byte.parseByte(OrderStatusEnum.UNPAYED.getCode() + ""));
            xbOrder.setShopNo(shopNo);
            xbOrder.setCreateTime(new Date());
            xbOrder.setTradeDone(Boolean.FALSE);
            logger.info("保存订单");
            int saveSuccess = 0;
            try {


                // 保存订单
                saveSuccess = xbOrderMapper.insert(xbOrder);
                if (saveSuccess > 0) {
                    logger.info("保存订单:{}成功！", xbOrder.getOrderNo());
                    XbOrderDetail orderDetail = null;
                    //保存详单
                    for (int i = 0; i < xbOrderDetailList.size(); i++) {
                        orderDetail = xbOrderDetailList.get(i);
                        int saveOrderDetail = xbOrderDetailMapper.insert(orderDetail);
                        logger.info("save {} order:{} detail successful!", saveOrderDetail, orderDetail.getOrderNo());
                        logger.info("生成订单号 保存订单及订单详情成功！");
                    }
                    logger.info("{}订单生成成功", xbOrder.getOrderNo());

                    //订单支付倒计时15分钟超时取消支付
                    RBucket<String> orderBucket = redissonClient.getBucket(xbOrder.getOpenId() + "#" + xbOrder.getOrderNo());
                    orderBucket.set("", 15 * 60L, TimeUnit.SECONDS);

                    return XbResult.build(0, 200, "生成订单成功", xbOrder);
                }
            } catch (RuntimeException e) {
                logger.error("保存订单数据失败！");
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        }

        return XbResult.build(400, 40009, "生成订单失败，请重试");
    }

    @ResponseBody
    public XbResult updateOrderPayByOrderNo(@RequestBody XbOrder xbOrder) {

        if (xbOrder == null || StringUtils.isEmpty(xbOrder.getOrderNo()) || StringUtils.isEmpty(xbOrder.getOpenId())) {
            return XbResult.build(30008, 200, "msg", "orderNo与openId不能为空");
        }


        XbOrderExample xbOrderExample = new XbOrderExample();
        XbOrderExample.Criteria criteria = xbOrderExample.createCriteria();
        //按openid orderno 为条件，更新
        criteria.andOpenIdEqualTo(xbOrder.getOpenId());
        criteria.andOrderNoEqualTo(xbOrder.getOrderNo());
        criteria.andOrderStatusEqualTo(Byte.parseByte(OrderStatusEnum.UNPAYED.getCode() + ""));

        List<XbOrder> xbOrders = xbOrderMapper.selectByExample(xbOrderExample);
        if (!CollectionUtils.isEmpty(xbOrders)) {
            XbOrder xbOrder1 = xbOrders.get(0);
            if (xbOrder1.getOrderAmountTotal().compareTo(xbOrder.getOrderAmountTotal()) != 0) {
                return XbResult.build(40019, 200, "msg", "orderNo=" + xbOrder.getOrderNo() + " 订单金额不正确!实际：" + xbOrder.getOrderAmountTotal() + " 订单金额：" + xbOrder1.getOrderAmountTotal());
            }
        } else {
            return XbResult.build(40018, 200, "msg", "orderNo=" + xbOrder.getOrderNo() + " 订单不存在或已支付完毕!");
        }

        XbOrder xbOrderUp = new XbOrder();
        //更新状态为已支付成功
        xbOrderUp.setOrderStatus(Byte.parseByte(OrderStatusEnum.PAYED.getCode() + ""));
        xbOrderUp.setPayTime(xbOrder.getPayTime());
        xbOrderUp.setOutTradeNo(xbOrder.getOutTradeNo());

        int updateOrder = xbOrderMapper.updateByExampleSelective(xbOrderUp, xbOrderExample);

        if (updateOrder > 0) {
            logger.info("更新{}订单保存成功：orderNo:{}", xbOrder.getOrderNo());
            return XbResult.build(0, 200, "xbOrder", xbOrder);
        } else {
            logger.info("更新订单保存失败：orderNo:{}", xbOrder.getOrderNo());
            return XbResult.build(400, 40009, "xbOrder", xbOrder);
        }

    }

    @ResponseBody
    public XbResult cancelOrderPayByOrderNo(@RequestBody OrderQuery orderQuery) {

        //判会话是否有效
        Object wxSessionObj = null;
        if (StringUtils.isEmpty(orderQuery.getSessionId())) {
            logger.error("没有用户信息!");
            return XbResult.build(400, 400, "没有用户信息!");
        } else {
            //从缓存中获取session_key
            RBucket<String> userBucket = redissonClient.getBucket(orderQuery.getSessionId());
            wxSessionObj = userBucket.get();
            if (null == wxSessionObj) {
                return XbResult.build(400, 40008, "session不存在");
            }
        }
        if (wxSessionObj == null) {
            return XbResult.build(400, 40008, "session不存在");
        }

        String openId = wxSessionObj.toString().split("#")[1];

        XbOrder xbOrder = new XbOrder();
        xbOrder.setOpenId(openId);
        xbOrder.setOrderNo(orderQuery.getOrderNo());


        if (xbOrder == null || StringUtils.isEmpty(xbOrder.getOrderNo()) || StringUtils.isEmpty(xbOrder.getOpenId())) {
            return XbResult.build(30008, 200, "msg", "orderNo与openId不能为空");
        }


        XbOrderExample xbOrderExample = new XbOrderExample();
        XbOrderExample.Criteria criteria = xbOrderExample.createCriteria();
        //按openid orderno 为条件，更新
        criteria.andOpenIdEqualTo(xbOrder.getOpenId());
        criteria.andOrderNoEqualTo(xbOrder.getOrderNo());
        criteria.andOrderStatusEqualTo(Byte.parseByte(OrderStatusEnum.UNPAYED.getCode() + ""));
        //

        XbOrder xbOrderUp = new XbOrder();
        //更新状态为订单取消
        xbOrderUp.setOrderStatus(Byte.parseByte(OrderStatusEnum.CANCELED.getCode() + ""));
        xbOrderUp.setPayTime(xbOrder.getPayTime());
        xbOrderUp.setOutTradeNo(xbOrder.getOutTradeNo());
        xbOrderUp.setPayChannel(Byte.parseByte(PayChannelEnum.CANCELED.getCode() + ""));

        int updateOrder = xbOrderMapper.updateByExampleSelective(xbOrderUp, xbOrderExample);

        if (updateOrder > 0) {
            logger.info("删除{}订单成功：orderNo:{}", xbOrder.getOpenId(), xbOrder.getOrderNo());
            return XbResult.build(0, 200, "xbOrder", xbOrder);
        } else {
            logger.info("删除{}订单失败：orderNo:{}", xbOrder.getOpenId(), xbOrder.getOrderNo());
            return XbResult.build(400, 40009, "xbOrder", xbOrder);
        }

    }

    /**
     * 获取订单列表
     *
     * @param orderQuery
     * @return
     */
    @Override
    @ApiOperation("获取订单列表")
    @ApiResponses(
            {
                    @ApiResponse(code = 200, message = "Successful — 请求已完成"),
                    @ApiResponse(code = 400, message = "请求中有语法问题，或不能满足请求"),
                    @ApiResponse(code = 401, message = "未授权客户机访问数据"),
                    @ApiResponse(code = 404, message = "服务器找不到给定的资源；文档不存在"),
                    @ApiResponse(code = 500, message = "服务器不能完成请求")
            }
    )
    @ResponseBody
    public XbResult findOrderList(@RequestBody OrderQuery orderQuery) {
        //判会话是否有效
        Object wxSessionObj = null;
        if (StringUtils.isEmpty(orderQuery.getSessionId())) {
            logger.error("没有用户信息!");
            return XbResult.build(400, 400, "没有用户信息!");
        } else {
            //从缓存中获取session_key
            RBucket<String> userBucket = redissonClient.getBucket(orderQuery.getSessionId());
            wxSessionObj = userBucket.get();
            if (null == wxSessionObj) {
                return XbResult.build(400, 40008, "session不存在");
            }
        }
        if (wxSessionObj == null) {
            return XbResult.build(400, 40008, "session不存在");
        }

        String openId = wxSessionObj.toString().split("#")[1];


        XbOrder xbOrder = new XbOrder();
        xbOrder.setOpenId(openId);
        //订单支付状态
        if (!StringUtils.isEmpty(orderQuery.getOrderStatus())) {
            xbOrder.setOrderStatus(Byte.parseByte(orderQuery.getOrderStatus().intValue() + ""));
        }
        //是否已经验货
        if (!StringUtils.isEmpty(orderQuery.getTradeDone())) {
            xbOrder.setTradeDone(orderQuery.getTradeDone());
        }
        //订单编号
        if (!StringUtils.isEmpty(orderQuery.getOrderNo())) {
            xbOrder.setOrderNo(orderQuery.getOrderNo());
        }

        //List<XbOrder> orderList0 = xbOrderMapper.selectOrderDetailInfoByOpenId(xbOrder);
        //AtomicLong orderTotal = new AtomicLong(0);
        //for (int i = 0; i < orderQuery.getiLength(); i++) {
        //    XbOrder xbOrder0 = orderList0.get(i);
        //    if (xbOrder0 != null && xbOrder0.getOrderDetailList() != null) {
        //        orderTotal.getAndAdd(xbOrder0.getOrderDetailList().size());
        //    }
        //}
        HashMap<String, Object> map = new HashMap<>();
        int pageNum = orderQuery.getiStart() / orderQuery.getiLength() + 1;
        PageHelper.startPage(pageNum, orderQuery.getiLength());

        List<XbOrder> orderList = xbOrderMapper.selectOrderDetailInfoByOpenId(xbOrder);

        List<UserOrder> userOrdersList = Lists.newArrayList();
        for (XbOrder xbOrder1 : orderList) {
            UserOrder userOrder = new UserOrder();
            BeanUtils.copyProperties(xbOrder1, userOrder);
            List<XbOrderDetail> orderDetailList = xbOrder1.getOrderDetailList();
            if (!CollectionUtils.isEmpty(orderDetailList)) {
                XbOrderDetail orderDetail0 = orderDetailList.get(0);
                userOrder.setGoodsName(orderDetail0.getGoodsName());
                userOrder.setPicUrl(orderDetail0.getPicUrl());
                userOrder.setSalePrice(orderDetail0.getSalePrice());
            }
            userOrdersList.add(userOrder);
        }

        PageInfo<UserOrder> pageInfo = new PageInfo<UserOrder>(userOrdersList);
        pageInfo.setTotal(userOrdersList.size());

        map.put("iTotalRecords", pageInfo.getTotal());//数据总条数
        map.put("iPageRecords", pageInfo.getSize());//显示的条数
        map.put("iData", userOrdersList);//数据集合

        return XbResult.build(0, 200, "查询成功", map);
    }


    public static void main(String[] args) {
        new BigDecimal("0.100000").compareTo(new BigDecimal("0000000.1"));
    }
}
