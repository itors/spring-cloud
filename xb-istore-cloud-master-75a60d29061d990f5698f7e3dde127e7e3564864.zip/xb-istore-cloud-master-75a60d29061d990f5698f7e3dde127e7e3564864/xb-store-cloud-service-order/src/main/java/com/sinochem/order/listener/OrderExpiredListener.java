package com.sinochem.order.listener;

import com.sinochem.enums.OrderStatusEnum;
import com.sinochem.mapper.XbOrderMapper;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderExample;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import redis.clients.jedis.JedisPubSub;

@Component
public class OrderExpiredListener extends JedisPubSub {

    private static final Logger logger = LoggerFactory.getLogger(OrderExpiredListener.class);

    private static XbOrderMapper xbOrderMapper;

    public OrderExpiredListener(XbOrderMapper xbOrderMapper) {
        if (xbOrderMapper != null) {
            OrderExpiredListener.xbOrderMapper = xbOrderMapper;
        }
    }

    @Override
    public int getSubscribedChannels() {

        return super.getSubscribedChannels();
    }

    @Override
    public boolean isSubscribed() {

        return super.isSubscribed();
    }

    @Override
    public void onMessage(String channel, String message) {

        super.onMessage(channel, message);
    }

    @Override
    public void onPMessage(String pattern, String channel, String message) {
        logger.info("order Expire listener message: {}", message);

        if (StringUtils.isEmpty(message)) {
            return;
        }
        //params
        String[] openOrder = message.split("#");
        if (openOrder.length != 2) {
            return;
        }

        String openId = openOrder[0];
        String orderNo = openOrder[1];


        if (StringUtils.isEmpty(openId) || StringUtils.isEmpty(orderNo)) {
            return;
        }

        if (!NumberUtils.isNumber(orderNo)) {
            return;
        }

        XbOrderExample xbOrderExample = new XbOrderExample();
        XbOrderExample.Criteria criteria = xbOrderExample.createCriteria();
        criteria.andOpenIdEqualTo(openId);
        criteria.andOrderNoEqualTo(orderNo);
        criteria.andOrderStatusEqualTo(Byte.valueOf(OrderStatusEnum.UNPAYED.getCode() + ""));

        XbOrder xbOrder = new XbOrder();
        xbOrder.setOrderStatus(Byte.valueOf(OrderStatusEnum.CANCELED.getCode() + ""));

        int clearNum = xbOrderMapper.updateByExampleSelective(xbOrder, xbOrderExample);

        if (clearNum > 0) {
            logger.info("OpenId:{} 的订单：{} 已超时，取消成功!", openId, orderNo);
        } else {
            logger.info("没有超时订单可处理....");
        }

        super.onPMessage(pattern, channel, message);
    }

    @Override
    public void onPSubscribe(String pattern, int subscribedChannels) {

        super.onPSubscribe(pattern, subscribedChannels);
    }

    @Override
    public void onPUnsubscribe(String pattern, int subscribedChannels) {

        super.onPUnsubscribe(pattern, subscribedChannels);
    }

    @Override
    public void onSubscribe(String channel, int subscribedChannels) {

        super.onSubscribe(channel, subscribedChannels);
    }

    @Override
    public void onUnsubscribe(String channel, int subscribedChannels) {

        super.onUnsubscribe(channel, subscribedChannels);
    }

    @Override
    public void psubscribe(String... patterns) {

        super.psubscribe(patterns);
    }

    @Override
    public void punsubscribe() {

        super.punsubscribe();
    }

    @Override
    public void punsubscribe(String... patterns) {

        super.punsubscribe(patterns);
    }

    @Override
    public void subscribe(String... channels) {

        super.subscribe(channels);
    }

    @Override
    public void unsubscribe() {

        super.unsubscribe();
    }

    @Override
    public void unsubscribe(String... channels) {

        super.unsubscribe(channels);
    }

}