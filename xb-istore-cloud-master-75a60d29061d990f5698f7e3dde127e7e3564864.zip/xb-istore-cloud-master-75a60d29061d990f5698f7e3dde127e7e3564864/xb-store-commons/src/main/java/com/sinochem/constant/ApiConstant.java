package com.sinochem.constant;

/**
 * API常量
 *
 * @author
 */
public class ApiConstant {

    /*获取用户信息*/
    public final static String GET_USER = "GET_USER";

    /*创建用户信息*/
    public final static String POST_USER = "POST_USER";

    /*更新用户信息*/
    public final static String PUT_USER = "PUT_USER";

    /*删除用户信息*/
    public final static String DELETE_USER = "DELETE_USER";


    /*微信code*/
    public static final String WX_CODE = "WX_CODE";
    //微信支付
    public static final String WX_PAY = "WX_PAY";

    /*校验微信用户信息完整性*/
    public static final String WX_CHECK_USER = "WX_CHECK_USER";
    /*用户会话信息*/
    public static final String WX_CHECK_USER_SESSION = "WX_CHECK_USER_SESSION";

    /*解密用户信息*/
    public static final String WX_DECODE_USERINFO = "WX_DECODE_USERINFO";

    /*手机是否已经存在*/
    public static final String WX_CHECK_PHONE = "WX_CHECK_PHONE";
    /*绑定手机*/
    public static final String WX_BIND_PHONE = "WX_BIND_PHONE";

    public static final String CART_ADD_GOODS = "CART_ADD_GOODS";

    public static final String ORDER_ADD_ORDER = "ORDER_ADD_ORDER";

    public static final String ORDER_GET_ORDERS = "ORDER_GET_ORDERS";

    public static final String ORDER_GET_ORDER = "ORDER_GET_ORDER";

    public static final String ORDER_DEL_ORDER = "ORDER_DEL_ORDER";
}
