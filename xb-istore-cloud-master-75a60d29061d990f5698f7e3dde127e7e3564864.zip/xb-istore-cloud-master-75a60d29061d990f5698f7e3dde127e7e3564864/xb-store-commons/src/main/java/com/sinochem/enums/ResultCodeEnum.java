package com.sinochem.enums;

/**
 * 支付返回值
 */
public enum ResultCodeEnum {
    SUCCESS("SUCCESS"), FAIL("FAIL");
    private String code;

    ResultCodeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
