package com.sinochem.enums;

/**
 * 支付渠道
 */
public enum PayChannelEnum {

    CANCELED(0, "订单取消"), WECHAT(1, "微信支付"), ALIPAY(2, "支付宝");

    int code;
    String message;
    PayChannelEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static String valueOf(Integer status) {
        if (status == null) {
            return "";
        } else {
            for (PayChannelEnum s : PayChannelEnum.values()) {
                if (s.getCode() == status) {
                    return s.getMessage();
                }
            }
            return "";
        }
    }
}
