package com.sinochem.enums;

/**
 * 订单状态
 */
public enum OrderStatusEnum {

    UNPAYED(0, "未付款"), PAYED( 1,"已付款"), CANCELED(2,"取消交易" );

    int code;
    String message;
    OrderStatusEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static String valueOf(Integer status) {
        if (status == null) {
            return "";
        } else {
            for (OrderStatusEnum s : OrderStatusEnum.values()) {
                if (s.getCode() == status) {
                    return s.getMessage();
                }
            }
            return "";
        }
    }
}
