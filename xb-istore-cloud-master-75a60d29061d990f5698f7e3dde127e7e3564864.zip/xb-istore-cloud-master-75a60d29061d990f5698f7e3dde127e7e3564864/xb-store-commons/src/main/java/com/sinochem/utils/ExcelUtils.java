package com.sinochem.utils;

/**
 * @description: excel导入导出工具类
 * @author: liuyuanzhi
 * @create 2018-03-09 下午3:07
 **/
public class ExcelUtils {
    /**
     * 检查是否excel 2003
     * @param filePath
     * @return
     */
    public static boolean isExcel2003(String filePath)  {
        return filePath.matches("^.+\\.(?i)(xls)$");
    }

    /**
     * 检查文件是否是excel 2007
     * @param filePath
     * @return
     */
    public static boolean isExcel2007(String filePath)  {
        return filePath.matches("^.+\\.(?i)(xlsx)$");
    }

    /**
     * excel文件校验
     * @param filePath
     * @return
     */
    public static boolean validateExcel(String filePath){
        if (filePath == null || !(isExcel2003(filePath) || isExcel2007(filePath))){
            return false;
        }
        return true;
    }
}
