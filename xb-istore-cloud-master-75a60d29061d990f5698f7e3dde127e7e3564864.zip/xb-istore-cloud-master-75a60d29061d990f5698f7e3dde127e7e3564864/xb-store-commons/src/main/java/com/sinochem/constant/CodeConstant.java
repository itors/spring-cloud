package com.sinochem.constant;

/**
 * @author liuming
 * 接口返回代码常量类
 *
 */
public class CodeConstant {

    /**
     * 返回成功
     */
    public final static int SUCCESS = 0;
    /**
     *返回操作失败
     */
    public final static int FAILURE = -1;

    /**
     *返回失败 服务器错误
     */
    public final static int FAILURE_SERVER = 500;

    /**
     *返回失败 参数异常
     */
    public final static int FAILURE_PARAM = 400;


}
