package com.sinochem.wechat.controller;

import com.google.common.collect.ImmutableMap;
import com.sinochem.aes.AES;
import com.sinochem.annotation.SCApi;
import com.sinochem.constant.ApiConstant;
import com.sinochem.pojo.XbUser;
import com.sinochem.utils.FastJsonConvert;
import com.sinochem.utils.RegexUtils;
import com.sinochem.wechat.service.WxService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.util.List;
import java.util.Map;

/**
 * wechat微信用户认证相关 Controller
 *
 * @author liuming
 * @create
 */
@Api(value = "wechatController API相关", tags = {"wechat-controller"}, description = "微信登录相关接口 Controller")
@RestController
@RefreshScope
public class WechatController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(WechatController.class);

    @Autowired
    private WxService wxService;
    @Autowired
    private RedissonClient redissonClient;

    /**
     * 根据客户端传过来的code从微信服务器获取appid和session_key，然后生成3rdkey返回给客户端，后续请求客户端传3rdkey来维护客户端登录态
     *
     * @param wxCode 小程序登录时获取的code
     * @return
     */
    @ApiOperation(value = "获取sessionId", notes = "小程序用户允许登录后，使用code 换取 session_key api，将 code 换成 openid 和 session_key")
    @SCApi(name = ApiConstant.WX_CODE)
    @RequestMapping(value = "/api/v1/wx/getSession", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> createSession(@ApiParam(name = "wxCode", value = "微信code", required = true) @RequestParam("wxCode") String wxCode) {
        Map<String, Object> wxSessionMap = wxService.getWxSession(wxCode);

        if (null == wxSessionMap) {
            return rtnParam(50010, null);
        }
        //获取异常
        if (wxSessionMap.containsKey("errcode")) {
            return rtnParam(Integer.parseInt(wxSessionMap.get("errcode").toString()), wxSessionMap.get("errmsg"));
        }
        String wxOpenId = (String) wxSessionMap.get("openid");
        String wxSessionKey = (String) wxSessionMap.get("session_key");
        logger.info("保存在redis中的用户sesion_key:", wxSessionKey);
        Long expires = 60 * 60 * 24L;
        String expires_in = (String) wxSessionMap.get("expires_in");
        if (!StringUtils.isEmpty(expires_in)) {
            expires = Long.valueOf(String.valueOf(expires_in));
        }
        String thirdSession = wxService.create3rdSession(wxOpenId, wxSessionKey, expires);
        return rtnParam(0, ImmutableMap.of("sessionId", thirdSession));
    }

    /**
     * 验证用户信息完整性
     *
     * @param rawData   微信用户基本信息
     * @param signature 数据签名
     * @param sessionId 会话ID
     * @return
     */
    @ApiOperation(value = "验证用户信息完整性", notes = "输入rawData、signature、sessionId验证用户信息完整性")
    @SCApi(name = ApiConstant.WX_CHECK_USER)
    @RequestMapping(value = "/api/v1/wx/checkUserInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> checkUserInfo(@ApiParam(name = "rawData", value = "微信用户基本信息", required = true) @RequestParam(required = true, value = "rawData") String rawData,
                                             @ApiParam(name = "signature", value = "数据签名", required = true) @RequestParam(required = true, value = "signature") String signature,
                                             @ApiParam(name = "sessionId", value = "会话ID", required = true) @RequestParam(required = true, value = "sessionId") String sessionId) {
        RBucket<String> userBucket = redissonClient.getBucket(sessionId);
        Object wxSessionObj = userBucket.get();
        if (null == wxSessionObj) {
            return rtnParam(40008, "session不存在");
        }
        String wxSessionStr = (String) wxSessionObj;
        String sessionKey = wxSessionStr.split("#")[0];
        StringBuffer sb = new StringBuffer(rawData);
        sb.append(sessionKey);
        //用十六进制sha1算法
        String encryData = DigestUtils.sha1Hex(sb.toString());

        Boolean checkStatus = signature.equals(encryData);
        return rtnParam(0, ImmutableMap.of("checkPass", checkStatus));
    }

    /**
     * 验证用户会话信息有效与否
     *
     * @param sessionId 会话ID
     * @return map
     */
    @ApiOperation(value = "验证用户会话信息有效与否", notes = "输入sessionId验证用户会话信息有效与否")
    @SCApi(name = ApiConstant.WX_CHECK_USER_SESSION)
    @RequestMapping(value = "/api/v1/wx/checkUserSession", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> checkSession(@ApiParam(name = "sessionId", value = "会话ID", required = true) @RequestParam(required = true, value = "sessionId") String sessionId) {
        RBucket<String> userBucket = redissonClient.getBucket(sessionId);
        Object wxSessionObj = userBucket.get();
        if (null == wxSessionObj) {
            return rtnParam(40008, ImmutableMap.of("checkSession", Boolean.FALSE, "msg", "session不存在"));
        }

        String wxSessionStr = (String) wxSessionObj;
        String wxOpenId = wxSessionStr.split("#")[1];

        return rtnParam(0, ImmutableMap.of("checkSession", Boolean.TRUE, "openId", wxOpenId));
    }


    /**
     * 获取用户openId和unionId数据(如果没绑定微信开放平台，解密数据中不包含unionId)
     *
     * @param encryptedData 加密数据
     * @param iv            加密算法的初始向量
     * @param sessionId     会话ID
     * @return
     */
    @ApiOperation(value = "获取用户openId和unionId数据", notes = "输入encryptedData、iv、sessionId获取用户openId和unionId数据")
    @SCApi(name = ApiConstant.WX_DECODE_USERINFO)
    @RequestMapping(value = "/api/v1/wx/decodeUserInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> decodeUserInfo(@ApiParam(name = "encryptedData", value = "加密数据", required = true) @RequestParam(required = true, value = "encryptedData") String encryptedData,
                                              @ApiParam(name = "iv", value = "加密算法的初始向量", required = true) @RequestParam(required = true, value = "iv") String iv,
                                              @ApiParam(name = "sessionId", value = "会话ID", required = true) @RequestParam(required = true, value = "sessionId") String sessionId) {
        logger.info("传入的加密数据:{}", encryptedData);
        logger.info("传入的加密算法的初始向量:{}", iv);
        logger.info("传入sessionId:{}", sessionId);
        //从缓存中获取session_key
        RBucket<String> userBucket = redissonClient.getBucket(sessionId);
        Object wxSessionObj = userBucket.get();
        if (null == wxSessionObj) {
            return rtnParam(40008, "session不存在");
        }
        String wxSessionStr = (String) wxSessionObj;
        String sessionKey = wxSessionStr.split("#")[0];

        try {
            AES aes = new AES();
            byte[] resultByte = aes.decrypt(Base64.decodeBase64(encryptedData), Base64.decodeBase64(sessionKey), Base64.decodeBase64(iv));
            if (null != resultByte && resultByte.length > 0) {
                String userInfo = new String(resultByte, "UTF-8");
                //保存user到DB
                XbUser xbUser = FastJsonConvert.convertJSONToObject(userInfo, XbUser.class);
                xbUser.setAppId((String) xbUser.getWatermark().get("appid"));

                int saveNum = wxService.saveUserInfo(xbUser);
                if (saveNum > 0) {
                    logger.info("user's openid={}保存成功！", xbUser.getOpenId());
                } else {
                    logger.info("user's openid={}保存失败！", xbUser.getOpenId());
                }

                return rtnParam(0, userInfo);
            }
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return rtnParam(50021, "解密失败，请确认小程序session是否还有效");
    }

    /**
     * 验证手机号是否已经存在
     *
     * @param sessionId 会话id
     * @return
     */
    @ApiOperation(value = "验证手机号是否已经存在", notes = "输入sessionId验证手机号是否已经存在")
    @SCApi(name = ApiConstant.WX_CHECK_PHONE)
    @RequestMapping(value = "/api/v1/wx/checkPhone", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> checkUserPhone(@ApiParam(name = "sessionId", value = "sessionId", required = true) @RequestParam(required = true, value = "sessionId") String sessionId) {
        if (StringUtils.isEmpty(sessionId)) {
            return rtnParam(40401, "请输入当前用户会话ID");
        }
        //获取session
        RBucket<String> userBucket = redissonClient.getBucket(sessionId);
        Object wxSessionObj = userBucket.get();
        if (null == wxSessionObj) {
            return rtnParam(40008, "session不存在");
        }

        String wxSessionStr = (String) wxSessionObj;
        String openId = wxSessionStr.split("#")[1];

        List<XbUser> xbUsers = wxService.getUserInfoByOpenId(openId);
        Boolean checkStatus = Boolean.FALSE;
        String phoneNumber = "";
        if (CollectionUtils.isEmpty(xbUsers)) {
            return rtnParam(40402, ImmutableMap.of("user for this OpenId not exist", "没有用户信息", "opendId", openId));
        } else {
            XbUser xbUser = xbUsers.get(0);
            phoneNumber = xbUser.getPhone();
            if (!StringUtils.isEmpty(phoneNumber)) {
                checkStatus = Boolean.TRUE;
            }
        }
        return rtnParam(0, ImmutableMap.of("checkExistPhone", checkStatus, "msg", checkStatus ? "手机号已经存在！" : "手机号不存在！"));
    }

    /**
     * 更新手机号
     *
     * @param phone  手机号
     * @param openId 微信openId
     * @return
     */
    @ApiOperation(value = "更新验证通过的手机号", notes = "输入phone更新已验证手机号")
    @SCApi(name = ApiConstant.WX_BIND_PHONE)
    @RequestMapping(value = "/api/v1/wx/bindPhone", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> updateUserPhone(@ApiParam(name = "phone", value = "手机号", required = true) @RequestParam(required = true, value = "phone") String phone
            , @ApiParam(name = "sessionId", value = "sessionId", required = true) @RequestParam(required = true, value = "sessionId") String sessionId) {
        if (StringUtils.isEmpty(phone)) {
            return rtnParam(40401, "请输入手机号");
        }
        if (!RegexUtils.checkMobile(phone)) {
            return rtnParam(40402, "请输入正确的手机号");
        }

        if (StringUtils.isEmpty(sessionId)) {
            return rtnParam(40401, "请输入当前用户会话ID");
        }
        //获取session
        RBucket<String> userBucket = redissonClient.getBucket(sessionId);
        Object wxSessionObj = userBucket.get();
        if (null == wxSessionObj) {
            return rtnParam(40008, "session不存在");
        }

        String wxSessionStr = (String) wxSessionObj;
        String openId = wxSessionStr.split("#")[1];

        XbUser xbUser = new XbUser();
        xbUser.setOpenId(openId);
        xbUser.setPhone(phone);
        int saveResult = wxService.saveUserInfo(xbUser);
        if (saveResult < 1) {
            return rtnParam(50001, ImmutableMap.of("savePhone", Boolean.TRUE, "msg", "保存失败！openId=" + openId));
        } else {
            return rtnParam(0, ImmutableMap.of("savePhoneSuccess", Boolean.TRUE, "msg", "保存成功！openId=" + openId));
        }
    }

    public static void main(String[] args) {
        String userInfo = "{\"openId\":\"oiDSt4hO51IoP3nzlqAgbT-ZnZ8k\",\"nickName\":\"Cocoon \uD83D\uDE48จุ๊บL\",\"gender\":2,\"language\":\"zh_CN\",\"city\":\"Baoding\",\"province\":\"Hebei\",\"country\":\"China\",\"avatarUrl\":\"https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIGJr4EuOKeez6EEAYwkcDG3nsEtDxq0E05J9okqTzRvwZUlPMuHO7Rk6hoxicKXESSNhFnXMHrnBQ/0\",\"unionId\":\"ozPRzwuJWwppGHew4lrbdeGbE4gc\",\"watermark\":{\"timestamp\":1520220813,\"appid\":\"wx26c260421cf772bf\"}}";
        XbUser xbUser = FastJsonConvert.convertJSONToObject(userInfo, XbUser.class);
        xbUser.setAppId((String) xbUser.getWatermark().get("appid"));
        logger.info(xbUser.toString());
    }
}
