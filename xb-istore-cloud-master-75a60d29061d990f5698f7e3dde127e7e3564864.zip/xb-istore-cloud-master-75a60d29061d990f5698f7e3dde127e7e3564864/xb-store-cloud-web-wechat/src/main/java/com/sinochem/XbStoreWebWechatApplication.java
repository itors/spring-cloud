package com.sinochem;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.sinochem.constant.ApiConstant;
import com.sinochem.properties.WxAuth;
import org.apache.catalina.connector.Connector;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 启动类
 *
 * @author liuming
 */
@Configuration
@EnableEurekaClient
@EnableFeignClients
@SpringBootApplication
@ComponentScan(value = "com.sinochem")
@EnableConfigurationProperties(value = {WxAuth.class})
//@EnableGlobalMethodSecurity(prePostEnabled = true)
public class XbStoreWebWechatApplication implements CommandLineRunner {

    @Autowired
    private Environment env;

    private static ImmutableMap<String, String> errorCodeMap = null;

    static {
        try {
            Properties prop = PropertiesLoaderUtils.loadAllProperties("error_code.properties");
            errorCodeMap = Maps.fromProperties(prop);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Bean(destroyMethod = "shutdown")
    public RedissonClient redissonClient() throws IOException {
        String[] profiles = env.getActiveProfiles();
        String profile = "";
        if (profiles.length > 0) {
            profile = "-" + profiles[0];
        }
        return Redisson.create(
                Config.fromYAML(new ClassPathResource("redisson" + profile + ".yml").getInputStream())
        );
    }

    public static void main(String[] args) {
        SpringApplication.run(XbStoreWebWechatApplication.class, args);
    }

    @Override
    public void run(String... arg0) throws Exception {
        String[] apiNames = new String[]{ApiConstant.GET_USER, ApiConstant.POST_USER, ApiConstant.PUT_USER,
                ApiConstant.DELETE_USER, ApiConstant.WX_CODE, ApiConstant.WX_DECODE_USERINFO};

        Map<String, Map<String, Integer>> apiMap = Maps.newHashMap();
        for (String apiName : apiNames) {
            Map<String, Integer> tmpMap = new HashMap<String, Integer>();
            tmpMap.put("calltimes", 0);
            tmpMap.put("alltimes", 10000);
            apiMap.put(apiName, tmpMap);
        }
    }

    @Bean
    public ImmutableMap<String, String> errorCodeMap() {
        return errorCodeMap;
    }

    @Bean
    public EmbeddedServletContainerFactory servletContainer() {
        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
        tomcat.addAdditionalTomcatConnectors(createStandardConnector());
        return tomcat;
    }

    @Bean
    public Integer port() {
        return SocketUtils.findAvailableTcpPort();
    }

    private Connector createStandardConnector() {
        Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
        connector.setScheme("http");
        connector.setPort(port());
        return connector;
    }


}