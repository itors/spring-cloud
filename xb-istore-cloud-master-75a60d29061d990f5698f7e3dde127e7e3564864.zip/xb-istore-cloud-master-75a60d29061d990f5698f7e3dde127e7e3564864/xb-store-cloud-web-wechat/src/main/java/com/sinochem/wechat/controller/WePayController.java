package com.sinochem.wechat.controller;


import com.alibaba.fastjson.JSON;
import com.google.common.collect.ImmutableMap;
import com.sinochem.annotation.SCApi;
import com.sinochem.constant.ApiConstant;
import com.sinochem.constant.Constant;
import com.sinochem.enums.ResultCodeEnum;
import com.sinochem.order.service.OrderService;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderPaidInfo;
import com.sinochem.pojo.XbPayInfo;
import com.sinochem.pojo.XbResult;
import com.sinochem.pojo.vo.PayInfo;
import com.sinochem.pojo.vo.PayInfoResult;
import com.sinochem.pojo.vo.PayNotifyResult;
import com.sinochem.pojo.vo.PayParams;
import com.sinochem.utils.BeanUtil;
import com.sinochem.utils.CommonUtil;
import com.sinochem.utils.HttpUtil;
import com.sinochem.utils.RandomUtils;
import com.sinochem.utils.SignUtil;
import com.sinochem.utils.TimeUtils;
import com.sinochem.utils.XmlUtil;
import com.sinochem.wechat.service.WxService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * wepay微信支付相关 Controller
 *
 * @author liuming
 * @create
 */
@Api(value = "wepayController API相关", tags = {"wepay-controller"}, description = "微信小程序支付相关接口 Controller")
@RestController
@RefreshScope
public class WePayController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(WePayController.class);

    @Autowired
    private WxService wxService;
    @Autowired
    private RedissonClient redissonClient;
    @Autowired
    private OrderService orderService;

    // 回调url
    @RequestMapping(value = "/api/v1/wx/payconfirm", method = {RequestMethod.POST, RequestMethod.GET}, produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String notify(HttpServletRequest request) {
        PayNotifyResult payNotifyResult = null;
        try {
            String xml = IOUtils.toString(request.getInputStream());
            logger.info("weixin pay notify result is " + xml);
            if (org.apache.commons.lang3.StringUtils.isBlank(xml)) {
                return getResult(ResultCodeEnum.FAIL, "接受参数为空");
            }

            logger.info("微信支付回调xml结果：" + xml.toString());
            Map<String, Object> resultMap = XmlUtil.parseXml(xml);
            logger.info("微信支付回调map结果：" + resultMap.toString());


            // 校验返回结果 签名
            String resultSign = SignUtil.sign(resultMap, Constant.APP_KEY);
            if (resultMap.get("sign") == null || !resultMap.get("sign").equals(resultSign)) {
                logger.info("sign is not correct, " + resultMap.get("sign") + " " + resultSign);
                throw new RuntimeException("签名校验不通过");
            }

            payNotifyResult = BeanUtil.map2Object(PayNotifyResult.class, resultMap);
            logger.info("微信支付回调result结果：" + payNotifyResult.toString());

            logger.info(JSON.toJSONString(payNotifyResult, true));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return getResult(ResultCodeEnum.FAIL, "解析异常");
        }
        XbOrderPaidInfo xbOrderPaidInfo = new XbOrderPaidInfo();
        if (payNotifyResult != null) {
            xbOrderPaidInfo.setAppid(payNotifyResult.getAppid());
            xbOrderPaidInfo.setAttach(payNotifyResult.getAttach());
            xbOrderPaidInfo.setBankType(payNotifyResult.getBankType());
            xbOrderPaidInfo.setCashFee(payNotifyResult.getCashFee());
            xbOrderPaidInfo.setCreateDate(new Date());
            xbOrderPaidInfo.setFeeType(payNotifyResult.getFeeType());
            xbOrderPaidInfo.setIsSubscribe(payNotifyResult.getIsSubscribe());
            xbOrderPaidInfo.setMchId(payNotifyResult.getMchId());
            xbOrderPaidInfo.setNonceStr(payNotifyResult.getNonceStr());
            xbOrderPaidInfo.setOpenid(payNotifyResult.getOpenid());
            xbOrderPaidInfo.setOutTradeNo(payNotifyResult.getOutTradeNo());
            xbOrderPaidInfo.setResultCode(payNotifyResult.getResultCode());
            xbOrderPaidInfo.setSign(payNotifyResult.getSign());
            xbOrderPaidInfo.setReturnCode(payNotifyResult.getReturnCode());
            xbOrderPaidInfo.setTimeEnd(payNotifyResult.getTimeEnd());
            xbOrderPaidInfo.setTotalFee(payNotifyResult.getTotalFee());
            xbOrderPaidInfo.setTradeType(payNotifyResult.getTradeType());
            xbOrderPaidInfo.setTransactionId(payNotifyResult.getTransactionId());
        }
        logger.info("回调已支付信息保存：xbOrderPaidInfo：{}", xbOrderPaidInfo);

        int paidSave = wxService.saveOrderPaidInfo(xbOrderPaidInfo);
        if (paidSave > 0) {
            logger.info("回调已支付信息保存成功：TransactionId:{}", xbOrderPaidInfo.getTransactionId());
        } else {
            logger.error("回调已支付信息保存失败：xbOrderPaidInfo:{}", xbOrderPaidInfo.toString());
        }

        XbOrder orderUp = new XbOrder();
        orderUp.setOutTradeNo(payNotifyResult.getTransactionId());
        SimpleDateFormat sdf = new SimpleDateFormat(Constant.TIME_FORMAT);

        try {
            orderUp.setPayTime(sdf.parse(payNotifyResult.getTimeEnd()));
        } catch (ParseException e) {
            logger.error("wapay controller-->notify 日期{}解析错误", payNotifyResult.getTimeEnd());
            e.printStackTrace();
        }
        orderUp.setOrderAmountTotal(new BigDecimal(payNotifyResult.getTotalFee()).divide(new BigDecimal("100")));
        orderUp.setOrderNo(payNotifyResult.getOutTradeNo());
        orderUp.setOpenId(payNotifyResult.getOpenid());
        //更新order状态
        XbResult orderUpdateR = orderService.updateOrderPayByOrderNo(orderUp);
        logger.info("更新order后返回状态：{}-{}-{}-{}",orderUpdateR.getErrorCode(),orderUpdateR.getStatus(),orderUpdateR.getMsg(),orderUpdateR.getData());
        if (orderUpdateR.getErrorCode().equals(0) && orderUpdateR.getStatus().equals(200)) {
            logger.info("更新order状态保存成功：getOrderNo:{}", orderUp.getOrderNo());
        } else {
            logger.info("更新order状态保存失败：getOrderNo:{}", orderUp.getOrderNo());
        }

        return getResult(ResultCodeEnum.SUCCESS, "OK");
    }


    /**
     * @param payParams
     * @return
     */
    @ApiOperation(value = "获取prepay", notes = "服务器端调用支付统一下单接口，调用该接口会在微信支付服务后台生成预支付交易单，同时返回prepay_id，这个prepay_id就是预支付的ID。后面小程序调用支付需要用到它 这里调用的接口链接为：\n" +
            "\n" +
            "https://api.mch.weixin.qq.com/pay/unifiedorder")
    @SCApi(name = ApiConstant.WX_PAY)
    @RequestMapping(value = "/api/v1/wx/prepay", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Map<String, Object> prePay(@ApiParam(name = "payParams", value = "订单参数{orderNo,orderFee,openId,clientId}", required = true) @RequestBody PayParams payParams) {

        logger.info("orderNo={}\n orderFee={}\n openId={}\n clientIp={}\n", payParams.getOrderNo(), payParams.getOrderFee(), payParams.getOpenId(), payParams.getClientIP());
        String content = null;
        Map map = new IdentityHashMap();
        ObjectMapper mapper = new ObjectMapper();

        boolean result = true;
        String info = "获取prepay成功！";

        logger.info("\n======================================================");
        logger.info("openId: " + payParams.getOpenId());

        PayInfoResult payInfoResult = new PayInfoResult();

        if (StringUtils.isEmpty(payParams.getOpenId())) {
            result = false;
            info = "获取到openId为空";
        } else {
            //payParams.getOpenId() = payParams.getOpenId().replace("\"", "").trim();

            logger.info("openId: " + payParams.getOpenId() + ", clientIP: " + payParams.getClientIP());


            //判断是否还可支付，15分钟内的订单可以支付
            RBucket<String> orderBucket = redissonClient.getBucket(payParams.getOpenId() + "#" + payParams.getOrderNo());
            Object orderObj = orderBucket.get();
            if (null == orderObj) {
                return rtnParam(40008, "orderNo:" + payParams.getOrderNo() + "不存在或已超时不能支付");
            }
            //生成32位随机数
            String randomNonceStr = RandomUtils.generateMixString(32);

            BigDecimal orderFeeBD = new BigDecimal(0.00);
            if (!StringUtils.isEmpty(payParams.getOrderFee())) {
                orderFeeBD = new BigDecimal(payParams.getOrderFee());
            }

            payInfoResult = unifiedOrder(payParams.getOpenId(), payParams.getOrderNo(), orderFeeBD, payParams.getClientIP(), randomNonceStr);

            String prepayId = payInfoResult.getPrepayId();

            logger.info("prepayId: " + prepayId);

            if (StringUtils.isEmpty(prepayId)) {
                result = false;
                info = "出错了，未获取到prepayId";

            } else {
                map.put("prepayId", prepayId);
                map.put("nonceStr", randomNonceStr);
                map.put("timeStamp", payInfoResult.getTimeStamp());
                map.put("paySign", payInfoResult == null ? "" : payInfoResult.getPaySign());
            }
        }

        try {
            map.put("result", result);
            map.put("info", info);
            content = mapper.writeValueAsString(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //调用预支付返回失败
        if (!result) {
            String payResult = payInfoResult.getReturnResult();
            return rtnParam(40008, ImmutableMap.of(result, payResult == null ? "" : payResult, "msg", info));
        }
        //返回成功
        if (result) {
            //保存预支付信息
            XbPayInfo payInfo = new XbPayInfo();
            payInfo.setOpenId(payInfoResult.getPayInfo().getOpenid());
            payInfo.setLimitPay(payInfoResult.getPayInfo().getLimit_pay());
            payInfo.setTradeType(payInfoResult.getPayInfo().getTrade_type());
            payInfo.setNotifyUrl(payInfoResult.getPayInfo().getNotify_url());
            payInfo.setTimeExpire(payInfoResult.getPayInfo().getTime_expire());
            payInfo.setTimeStart(payInfoResult.getPayInfo().getTime_start());
            payInfo.setTradeType(payInfoResult.getPayInfo().getTrade_type());
            payInfo.setSpbillCreateIp(payInfoResult.getPayInfo().getSpbill_create_ip());
            payInfo.setTotalFee(new BigDecimal(payInfoResult.getPayInfo().getTotal_fee()).divide(new BigDecimal(100)));
            payInfo.setOutTradeNo(payInfoResult.getPayInfo().getOut_trade_no());
            payInfo.setSignType(payInfoResult.getPayInfo().getSign_type());
            payInfo.setNonceStr(payInfoResult.getPayInfo().getNonce_str());
            payInfo.setDeviceInfo(payInfoResult.getPayInfo().getDevice_info());
            payInfo.setMchId(payInfoResult.getPayInfo().getMch_id());
            payInfo.setAppId(payInfoResult.getPayInfo().getAppid());
            payInfo.setAttach(payInfoResult.getPayInfo().getAttach());
            payInfo.setBody(payInfoResult.getPayInfo().getBody());
            payInfo.setCreateDate(new Date());

            int paySave = wxService.savePayInfo(payInfo);
            if (paySave > 0) {
                logger.info("回调预支付信息保存成功：getOutTradeNo:{}", payInfo.getOutTradeNo());
            } else {
                logger.info("回调预支付信息保存失败：payInfo:{}", payInfo.toString());
            }
        }
        return rtnParam(0, map);
    }


    /**
     * 调用统一下单接口
     *
     * @param openId
     */
    private PayInfoResult unifiedOrder(String openId, String orderNo, BigDecimal orderFee, String clientIP, String randomNonceStr) {

        PayInfoResult payInfoResult = new PayInfoResult();
        PayInfo payInfo = new PayInfo();
        try {

            String url = Constant.URL_UNIFIED_ORDER;
            logger.info("URL_UNIFIED_ORDER = {}", url);
            payInfo = createPayInfo(openId, orderNo, orderFee, clientIP, randomNonceStr);
            String md5 = getSign(payInfo);
            payInfo.setSign(md5);

            logger.info("md5 value: " + md5);

            String xml = CommonUtil.payInfoToXML(payInfo);
            //xml = xml.replace("__", "_").replace("<![CDATA[1]]>", "1");
            xml = xml.replace("__", "_").replace("<![CDATA[", "").replace("]]>", "");
            logger.info(xml);

            StringBuffer buffer = HttpUtil.httpsRequest(url, "POST", xml);
            logger.info("unifiedOrder request return body: \n" + buffer.toString());
            Map<String, String> result = CommonUtil.parseXml(buffer.toString());
            logger.info("unifiedOrder-->result=={}", result.toString());
            if (result != null) {
                payInfoResult.setReturnResult(result.toString());
            }
            String return_code = result.get("return_code");
            String return_msg = result.get("return_msg");


            logger.info("unifiedOrder-->return_code=={}", return_code);
            if (!StringUtils.isEmpty(return_code) && return_code.equals("SUCCESS")) {
                if (!StringUtils.isEmpty(return_msg) && !return_msg.equals("OK")) {
                    logger.error("统一下单错误！code:{}-msg:{}", return_code, return_msg);
                }

                payInfo.setPrepayId(result.get("prepay_id"));

            }

        } catch (Exception e) {
            logger.error("微信统一下单接口异常：{}-{}", e.getMessage(), e);
            e.printStackTrace();
        }
        String timeStamp = Long.toString(System.currentTimeMillis());
        String signAgain = null;
        try {
            signAgain = this.getSignAgain(payInfo.getAppid(), payInfo.getNonce_str(), payInfo.getPrepayId(), timeStamp);
        } catch (Exception e) {
            logger.error("再sign时出现异常：{}-{}", e.getMessage(), e);
            e.printStackTrace();
        }

        payInfoResult.setNonceStr(payInfo.getNonce_str());
        payInfoResult.setPacKage("prepay_id=" + payInfo.getPrepayId());
        payInfoResult.setPaySign(signAgain);
        payInfoResult.setPrepayId(payInfo.getPrepayId());
        payInfoResult.setSignType("MD5");
        payInfoResult.setTimeStamp(timeStamp);
        payInfoResult.setPayInfo(payInfo);

        return payInfoResult;
    }

    private PayInfo createPayInfo(String openId, String orderNo, BigDecimal orderFee, String clientIP, String randomNonceStr) {

        Date date = new Date();
        String timeStart = TimeUtils.getFormatTime(date, Constant.TIME_FORMAT);
        String timeExpire = TimeUtils.getFormatTime(TimeUtils.addDay(date, Constant.TIME_EXPIRE), Constant.TIME_FORMAT);

        PayInfo payInfo = new PayInfo();
        payInfo.setAppid(Constant.APP_ID);
        payInfo.setMch_id(Constant.MCH_ID);
        payInfo.setDevice_info("WEB");
        payInfo.setNonce_str(randomNonceStr);
        payInfo.setSign_type("MD5");  //默认即为MD5
        payInfo.setBody("iStore微信支付");
        payInfo.setAttach("iStore微信支付");
        payInfo.setOut_trade_no(orderNo);
        payInfo.setTotal_fee(orderFee.multiply(new BigDecimal(100)).intValue());
        payInfo.setSpbill_create_ip(clientIP);
        payInfo.setTime_start(timeStart);
        payInfo.setTime_expire(timeExpire);
        payInfo.setNotify_url(Constant.URL_NOTIFY);
        payInfo.setTrade_type("JSAPI");
        payInfo.setLimit_pay("no_credit");
        payInfo.setOpenid(openId);

        return payInfo;
    }

    private String getSign(PayInfo payInfo) throws Exception {
        StringBuffer sb = new StringBuffer();
        sb.append("appid=" + payInfo.getAppid())
                .append("&attach=" + payInfo.getAttach())
                .append("&body=" + payInfo.getBody())
                .append("&device_info=" + payInfo.getDevice_info())
                .append("&limit_pay=" + payInfo.getLimit_pay())
                .append("&mch_id=" + payInfo.getMch_id())
                .append("&nonce_str=" + payInfo.getNonce_str())
                .append("&notify_url=" + payInfo.getNotify_url())
                .append("&openid=" + payInfo.getOpenid())
                .append("&out_trade_no=" + payInfo.getOut_trade_no())
                .append("&sign_type=" + payInfo.getSign_type())
                .append("&spbill_create_ip=" + payInfo.getSpbill_create_ip())
                .append("&time_expire=" + payInfo.getTime_expire())
                .append("&time_start=" + payInfo.getTime_start())
                .append("&total_fee=" + payInfo.getTotal_fee())
                .append("&trade_type=" + payInfo.getTrade_type())
                .append("&key=" + Constant.APP_KEY);

        logger.info("排序后的拼接支付参数：" + sb.toString());

        return CommonUtil.getMD5(sb.toString().trim()).toUpperCase();
    }

    private String getSignAgain(String appId, String nonceStr, String prepayId, String timeStamp) throws Exception {
        StringBuffer sb = new StringBuffer();
        sb.append("appId=" + appId)
                .append("&nonceStr=" + nonceStr)
                .append("&package=prepay_id=" + prepayId)
                .append("&signType=MD5")
                .append("&timeStamp=" + timeStamp)
                .append("&key=" + Constant.APP_KEY);

        logger.info("再sign排序后的拼接支付参数：" + sb.toString());

        return CommonUtil.getMD5(sb.toString().trim()).toUpperCase();
    }


    public static String getSigns(PayInfo payInfo) throws Exception {
        StringBuffer sb = new StringBuffer();
        sb.append("appid=" + payInfo.getAppid())
                .append("&attach=" + payInfo.getAttach())
                .append("&body=" + payInfo.getBody())
                .append("&device_info=" + payInfo.getDevice_info())
                .append("&limit_pay=" + payInfo.getLimit_pay())
                .append("&mch_id=" + payInfo.getMch_id())
                .append("&nonce_str=" + payInfo.getNonce_str())
                .append("&notify_url=" + payInfo.getNotify_url())
                .append("&openid=" + payInfo.getOpenid())
                .append("&out_trade_no=" + payInfo.getOut_trade_no())
                .append("&sign_type=" + payInfo.getSign_type())
                .append("&spbill_create_ip=" + payInfo.getSpbill_create_ip())
                .append("&time_expire=" + payInfo.getTime_expire())
                .append("&time_start=" + payInfo.getTime_start())
                .append("&total_fee=" + payInfo.getTotal_fee())
                .append("&trade_type=" + payInfo.getTrade_type())
                .append("&key=" + Constant.APP_KEY);

        logger.info("排序后的拼接支付参数：" + sb.toString());

        return CommonUtil.getMD5(sb.toString().trim()).toUpperCase();
    }

    public static String getResult(ResultCodeEnum resultCode, String returnMsg) {
        Map<String, Object> data = new HashMap<String, Object>(2);
        data.put("return_code", resultCode.getCode());
        data.put("return_msg", returnMsg);
        return XmlUtil.toXml(data);
    }

    public static void main(String[] args) {
        PayInfo payInfo = new PayInfo();
        payInfo.setOpenid("o4WTl5ZULhaLMx84T_bJ6F-xAvdA");
        payInfo.setLimit_pay("no_credit");
        payInfo.setTrade_type("JSAPI");
        payInfo.setNotify_url("https://istore.1chemfinance.com/wechat/api/v1/wx/payconfirm");
        payInfo.setTime_expire("20180323155640");
        payInfo.setTime_start("20180321155640");
        payInfo.setSpbill_create_ip("0.0.0.0");
        payInfo.setTotal_fee(1);
        payInfo.setOut_trade_no("426021952608522240");
        payInfo.setSign_type("MD5");
        payInfo.setNonce_str("5L3sugck9uGn1FKbC6u1d9oOE1qrbFCs");
        payInfo.setDevice_info("WEB");
        payInfo.setMch_id("1500150072");
        payInfo.setAppid("wx9a0502af4218dfe1");
        payInfo.setAttach("iStore微信支付");
        payInfo.setBody("iStore微信支付");
        try {
            String md5 = WePayController.getSigns(payInfo);
            logger.info(md5);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
