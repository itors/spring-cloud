package com.sinochem.constant;

/**
 */
public class Constant {

    public static final String DOMAIN = "https://istore.1chemfinance.com";

    public static final String APP_ID = "wx9a0502af4218dfe1";

    public static final String APP_SECRET = "1d452e6fa79f2f279ff0ff4265032d7f";

    public static final String APP_KEY = "FLIMvqrMjbp7EJRLOOPUkZp76uyoubwE";

    public static final String MCH_ID = "1500150072";  //商户号

    public static final String URL_UNIFIED_ORDER = "https://api.mch.weixin.qq.com/pay/unifiedorder";

    public static final String URL_NOTIFY = Constant.DOMAIN + "/wechat/api/v1/wx/payconfirm";

    public static final String TIME_FORMAT = "yyyyMMddHHmmss";

    public static final int TIME_EXPIRE = 2;  //单位是day

}
