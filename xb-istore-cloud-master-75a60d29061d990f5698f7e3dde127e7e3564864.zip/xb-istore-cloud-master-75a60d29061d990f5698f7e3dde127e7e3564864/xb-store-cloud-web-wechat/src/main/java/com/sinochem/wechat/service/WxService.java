package com.sinochem.wechat.service;


import com.sinochem.pojo.XbOrderPaidInfo;
import com.sinochem.pojo.XbPayInfo;
import com.sinochem.pojo.XbUser;

import java.util.List;
import java.util.Map;

/**
 * 微信服务接口
 *
 * @author liuming
 * @create
 */

public interface WxService {
    /**
     * @param wxCode
     * @return
     */
    public Map<String, Object> getWxSession(String wxCode);

    /**
     * @param wxOpenId
     * @param wxSessionKey
     * @param expires
     * @return
     */
    public String create3rdSession(String wxOpenId, String wxSessionKey, Long expires);

    /**
     * 保存User信息到DB
     *
     * @param xbUser
     * @return
     */
    public int saveUserInfo(XbUser xbUser);

    /**
     * 按openId查询用户信息
     *
     * @param openId
     * @return
     */
    public List<XbUser> getUserInfoByOpenId(String openId);


    /**
     * 保存预支付信息到DB
     *
     * @param xbPayInfo
     * @return
     */
    public int savePayInfo(XbPayInfo xbPayInfo);

    /**
     * 保存已支付信息到DB
     *
     * @param xbOrderPaidInfo
     * @return
     */
    public int saveOrderPaidInfo(XbOrderPaidInfo xbOrderPaidInfo);
}
