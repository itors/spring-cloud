package com.sinochem.wechat.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sinochem.mapper.XbOrderPaidInfoMapper;
import com.sinochem.mapper.XbPayInfoMapper;
import com.sinochem.mapper.XbUserMapper;
import com.sinochem.pojo.XbOrderPaidInfo;
import com.sinochem.pojo.XbOrderPaidInfoExample;
import com.sinochem.pojo.XbPayInfo;
import com.sinochem.pojo.XbUser;
import com.sinochem.pojo.XbUserExample;
import com.sinochem.properties.WxAuth;
import com.sinochem.utils.HttpRequest;
import com.sinochem.wechat.service.WxService;
import org.apache.commons.lang3.RandomStringUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 微信小程序接口服务包装类
 *
 * @author liuming
 */
@Service
@MapperScan(basePackages = "com.sinochem.mapper")
public class WxServiceImpl implements WxService {

    private static final Logger logger = LoggerFactory.getLogger(WxServiceImpl.class);

    @Autowired
    private WxAuth wxAuth;

    @Autowired
    private RedissonClient redissonClient;

    @Autowired
    private XbUserMapper userMapper;
    @Autowired
    private XbPayInfoMapper xbPayInfoMapper;
    @Autowired
    private XbOrderPaidInfoMapper xbOrderPaidInfoMapper;


    /**
     * 保存预支付信息到DB
     *
     * @param xbPayInfo
     * @return
     */
    @Override
    public int savePayInfo(XbPayInfo xbPayInfo) {
        if (xbPayInfo == null) {
            return 0;
        }
        logger.info("生成预支付信息：xbPayInfo：{}", xbPayInfo.toString());
        //新增预支付信息
        return xbPayInfoMapper.insert(xbPayInfo);
    }

    /**
     * 保存已支付信息到DB
     *
     * @param xbOrderPaidInfo
     * @return
     */
    @Override
    public int saveOrderPaidInfo(XbOrderPaidInfo xbOrderPaidInfo) {
        //判空
        if (xbOrderPaidInfo == null) {
            return 0;
        }
        logger.info("生成已支付信息：xbOrderPaidInfo：{}", xbOrderPaidInfo.toString());

        XbOrderPaidInfoExample xbOrderPaidInfoExample = new XbOrderPaidInfoExample();
        XbOrderPaidInfoExample.Criteria criteria = xbOrderPaidInfoExample.createCriteria();
        criteria.andTransactionIdEqualTo(xbOrderPaidInfo.getTransactionId());
        List<XbOrderPaidInfo> xbOrderPaidInfoList = xbOrderPaidInfoMapper.selectByExample(xbOrderPaidInfoExample);
        if (!CollectionUtils.isEmpty(xbOrderPaidInfoList)) {
            if (xbOrderPaidInfoList.size() > 1) {
                logger.error("支付信息TransactionId:{}不唯一", xbOrderPaidInfo.getTransactionId());
                return -1;
            }
            //更新已支付信息
            return xbOrderPaidInfoMapper.updateByExampleSelective(xbOrderPaidInfo, xbOrderPaidInfoExample);
        }
        xbOrderPaidInfo.setCreateDate(new Date());
        //新增已支付信息
        return xbOrderPaidInfoMapper.insert(xbOrderPaidInfo);
    }


    /**
     * 根据小程序登录返回的code获取openid和session_key
     * https://mp.weixin.qq.com/debug/wxadoc/dev/api/api-login.html?t=20161107
     *
     * @param wxCode
     * @return
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getWxSession(String wxCode) {
        StringBuffer sb = new StringBuffer();
        sb.append("appid=").append(wxAuth.getAppId());
        sb.append("&secret=").append(wxAuth.getSecret());
        sb.append("&js_code=").append(wxCode);
        sb.append("&grant_type=").append(wxAuth.getGrantType());
        String res = HttpRequest.sendGet(wxAuth.getSessionHost(), sb.toString());
        if (res == null || res.equals("")) {
            return null;
        }
        return JSON.parseObject(res, Map.class);
    }

    /**
     * 缓存微信openId和session_key
     *
     * @param wxOpenId     微信用户唯一标识
     * @param wxSessionKey 微信服务器会话密钥
     * @param expires      会话有效期, 以秒为单位, 例如2592000代表会话有效期为30天
     * @return
     */
    public String create3rdSession(String wxOpenId, String wxSessionKey, Long expires) {
        String thirdSessionKey = RandomStringUtils.randomAlphanumeric(64);
        StringBuffer sb = new StringBuffer();
        sb.append(wxSessionKey).append("#").append(wxOpenId);
        RBucket<String> bucket = redissonClient.getBucket(thirdSessionKey);
        bucket.set(sb.toString(), expires.intValue(), TimeUnit.SECONDS);
        return thirdSessionKey;
    }

    /**
     * 保存用户信息到DB
     *
     * @param xbUser
     * @return
     */
    @Override
    public int saveUserInfo(XbUser xbUser) {
        if (xbUser == null) {
            return 0;
        }
        XbUserExample xbUserExample = new XbUserExample();
        XbUserExample.Criteria criteria = xbUserExample.createCriteria();
        criteria.andOpenIdEqualTo(xbUser.getOpenId());
        List<XbUser> xbUserList = userMapper.selectByExample(xbUserExample);
        xbUser.setUpdateDate(new Date());
        if (!CollectionUtils.isEmpty(xbUserList)) {
            if (xbUserList.size() > 1) {
                return -1;
            }
            //更新用户信息
            return userMapper.updateByExampleSelective(xbUser, xbUserExample);
        }
        xbUser.setCreateDate(new Date());
        //新增用户信息
        return userMapper.insert(xbUser);
    }

    /**
     * 返回按openId查询的用户信息
     *
     * @param openId
     * @return
     */
    public List<XbUser> getUserInfoByOpenId(String openId) {
        if (StringUtils.isEmpty(openId)) {
            return Lists.newArrayList();
        }
        XbUserExample xbUserExample = new XbUserExample();
        XbUserExample.Criteria criteria = xbUserExample.createCriteria();
        criteria.andOpenIdEqualTo(openId);
        return userMapper.selectByExample(xbUserExample);
    }

}
