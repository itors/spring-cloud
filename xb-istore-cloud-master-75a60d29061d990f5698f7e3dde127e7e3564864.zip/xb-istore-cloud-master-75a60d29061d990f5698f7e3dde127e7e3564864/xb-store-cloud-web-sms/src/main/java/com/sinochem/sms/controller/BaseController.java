package com.sinochem.sms.controller;


import com.sinochem.pojo.Response;

public abstract class BaseController {
    protected Response rtnParam(Integer errorCode, String data){
        if (errorCode.intValue() == 0) {
            return new Response(0,data);
        } else {
            return new Response(errorCode,data);
        }
    }
}
