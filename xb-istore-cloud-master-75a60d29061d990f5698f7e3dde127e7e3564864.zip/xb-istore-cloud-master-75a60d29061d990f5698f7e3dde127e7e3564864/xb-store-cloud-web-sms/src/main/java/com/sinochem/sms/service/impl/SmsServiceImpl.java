package com.sinochem.sms.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.sinochem.mapper.XbSmsLogsMapper;
import com.sinochem.pojo.XbSmsLogs;
import com.sinochem.sms.dao.SmsDao;
import com.sinochem.sms.service.SmsService;
import com.sinochem.sms.util.CheckSumBuilderUtils;
import io.swagger.annotations.Api;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
@MapperScan(basePackages = "com.sinochem.mapper")
@Api(value = "API - SmsServiceImpl", description = "短信操作")
@RestController
@RefreshScope
public class SmsServiceImpl implements SmsService{
    private final static Logger LOG = LoggerFactory.getLogger(SmsServiceImpl.class);
    @Value("${smsService.serviceUrl.send}")
    private String sendUrl;
    @Value("${smsService.serviceUrl.verify}")
    private String verifyUrl;
    @Value("${smsService.serviceUrl.appKey}")
    private String appKey;
    @Value("${smsService.serviceUrl.appSecret}")
    private String appSecret;
    @Value("${smsService.serviceUrl.templateId}")
    private String templateId;
    @Value("${smsService.serviceUrl.codeLen}")
    private String codeLen;
    @Value("${redisExpire}")
    private Long redisExpire;
    @Autowired
    private RedissonClient redissonClient;
    @Autowired
    @SuppressWarnings("SpringJavaAutowiringInspection")
    private SmsDao smsDao;

    /**
     * 验证码是否过期
     * @param mobile
     * @return
     */
    public boolean isExpired(String mobile){
        RBucket<String> bucket = redissonClient.getBucket(mobile);
        if(bucket==null || StringUtils.isBlank(bucket.get())){
            return true;
        }
        return false;
    }


    /**
     * 发送验证码
     * @param mobile
     * @return
     */
    @Transactional
    public boolean sendCode(String mobile){
        if(StringUtils.isBlank(mobile)){
            return false;
        }
        boolean retVal = false;
        Map<String,String> headerMap = new HashMap<>();
        String curTime = String.valueOf((new Date()).getTime() / 1000L);
        String nonce = getRandom();
        String checkSum = CheckSumBuilderUtils.getCheckSum(appSecret, nonce, curTime);

        headerMap.put("AppKey", appKey);
        headerMap.put("Nonce", nonce);
        headerMap.put("CurTime", curTime);
        headerMap.put("CheckSum", checkSum);

        Map<String,String> pairMap = new HashMap<>();
        if(StringUtils.isNotBlank(templateId)) {
            pairMap.put("templateid", templateId);
        }
        pairMap.put("mobile", mobile);
        pairMap.put("codeLen", codeLen);
        String response = null;

        try {
            response = post(headerMap,pairMap,sendUrl);
            JSONObject sendObj = JSON.parseObject(response);
            if(sendObj!=null && sendObj.getInteger("code")==200){
                RBucket<String> bucket = redissonClient.getBucket(mobile);
                bucket.set(mobile,redisExpire, TimeUnit.SECONDS);
                retVal = true;
            }
        } catch (IOException e) {
            LOG.error("发送验证码失败,{}",mobile,e);
        }
        XbSmsLogs smsLogs = new XbSmsLogs(sendUrl,new Date(),JSON.toJSONString(headerMap)+JSON.toJSONString(pairMap),response);
        smsDao.insert(smsLogs);
        return retVal;
    }


    /**
     * 验证码校验
     * @param mobile
     * @param code
     * @return
     */
    @Transactional
    public boolean verifyCode(String mobile,String code){
        if(StringUtils.isBlank(code)){
            return false;
        }
        boolean retVal = false;
        Map<String,String> headerMap = Maps.newHashMap();
        String curTime = String.valueOf((new Date()).getTime() / 1000L);
        String nonce = getRandom();
        String checkSum = CheckSumBuilderUtils.getCheckSum(appSecret, nonce, curTime);

        headerMap.put("AppKey", appKey);
        headerMap.put("Nonce", nonce);
        headerMap.put("CurTime", curTime);
        headerMap.put("CheckSum", checkSum);

        Map<String,String> pairMap = Maps.newHashMap();
        pairMap.put("mobile", mobile);
        pairMap.put("code", code);
        String response = null;
        try {
            response = post(headerMap,pairMap,verifyUrl);
            JSONObject verifyObj = JSON.parseObject(response);
            if(verifyObj!=null && verifyObj.getInteger("code")==200){
                retVal = true;
            }
        } catch (IOException e) {
            LOG.error("校验短信验证码失败,{},{}",mobile,code,e);
        }
        XbSmsLogs smsLogs = new XbSmsLogs(sendUrl,new Date(),JSON.toJSONString(headerMap)+JSON.toJSONString(pairMap),response);
        smsDao.insert(smsLogs);
        return retVal;
    }

    private String post(Map<String,String> headerMap, Map<String,String> pairMap,String url) throws IOException {
        String responseStr = null;
        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        for(Map.Entry<String,String> entry: headerMap.entrySet()){
            httpPost.addHeader(entry.getKey(),entry.getValue());
        }
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        for(Map.Entry<String,String> entry: pairMap.entrySet()){
            nvps.add(new BasicNameValuePair(entry.getKey(),entry.getValue()));
        }

        httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));
        HttpResponse response = httpClient.execute(httpPost);
        responseStr = EntityUtils.toString(response.getEntity(), "utf-8");
        System.out.println(responseStr);
        return responseStr;
    }

    private String getRandom(){
        return  String.valueOf((int) (Math.random() * 9000 + 1000));
    }
}
