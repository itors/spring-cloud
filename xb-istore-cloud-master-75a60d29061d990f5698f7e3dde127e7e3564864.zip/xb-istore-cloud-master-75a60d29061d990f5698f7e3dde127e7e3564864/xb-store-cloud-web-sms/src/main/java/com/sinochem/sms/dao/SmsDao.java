package com.sinochem.sms.dao;

import com.sinochem.mapper.XbSmsLogsMapper;
import com.sinochem.pojo.XbSmsLogs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @description: sms dao
 * @author: liuyuanzhi
 * @create 2018-03-07 下午8:21
 **/
@Repository
public class SmsDao {
    private final static Logger LOG = LoggerFactory.getLogger(SmsDao.class);

    @Autowired
    private XbSmsLogsMapper xbSmsLogsMapper;

    public void insert(XbSmsLogs logs){
        xbSmsLogsMapper.insert(logs);
    }
}
