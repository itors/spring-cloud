package com.sinochem.sms.controller;

import com.sinochem.pojo.Response;
import com.sinochem.sms.service.SmsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @description: 短信接口
 * @author: liuyuanzhi
 * @create 2018-03-06 下午3:03
 **/
@Api(value = "smsController API相关",tags = {"sms-controller"},description = "短信 Controller")
@RestController
@RefreshScope
public class SmsController extends BaseController{
    private static final Logger logger = LoggerFactory.getLogger(SmsController.class);

    @Autowired
    private SmsService smsService;

    @ApiOperation(value = "发送短信验证码", notes = "短信验证码发送接口")
    @RequestMapping(value = "/sendCode",method = {RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response sendCode(@ApiParam(name = "mobile",value = "电话号码")@RequestBody Map<String,String> reqMap){
        String mobile = reqMap.get("mobile");
        boolean isExpired = smsService.isExpired(mobile);
        if(!isExpired){
            return rtnParam(0,"短信验证码已发送");//验证码不能重复发送
        }
        boolean isSended = smsService.sendCode(mobile);
        if(!isSended){
            return rtnParam(202,"短信验证码发送失败");//验证码发送失败
        }
        return rtnParam(0,null);
    }

    @ApiOperation(value = "校验短信验证码",notes = "校验短信验证码接口")
    @RequestMapping(value = "/verifyCode",method = {RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response verifyCode(@ApiParam(name = "mobile,code",value="电话号码和验证码")@RequestBody Map<String,String> reqMap){
        String mobile = reqMap.get("mobile");
        String code = reqMap.get("code");
        boolean verifyPass = smsService.verifyCode(mobile,code);
        if(!verifyPass){
            return rtnParam(203,"验证码已失效");//验证失败
        }
        return rtnParam(0,null);
    }
}
