package com.sinochem.sms.service;

/**
 * @description: 短信service层
 * @author: liuyuanzhi
 * @create 2018-03-06 下午3:11
 **/
public interface SmsService {
    /**
     * 验证码是否过期
     * @param mobile
     * @return
     */
    public boolean isExpired(String mobile);

    /**
     * 发送验证码
     * @param mobile
     * @return
     */
    public boolean sendCode(String mobile);

    /**
     * 校验验证码
     * @param mobile
     * @param code
     * @return
     */
    public boolean verifyCode(String mobile,String code);
}
