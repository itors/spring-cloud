package com.sinochem.filter;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.RequestWrapper;

/**
 * @description: zuul filter支持websocket（弃用）
 * @author: liuyuanzhi
 * @create 2018-03-28 下午3:06
 **/
@Component
public class WebSocketHeaderFilter extends ZuulFilter {

    private final static Logger LOG = LoggerFactory.getLogger(WebSocketHeaderFilter.class);
    @Override
    public String filterType() {
        return "pre";
    }

    @Override
    public int filterOrder() {
        return 0;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();
//        RequestWrapper wrapper = new RequestWrapper(ctx.getRequest());
        String upgradeHeader = request.getHeader("Upgrade");
        LOG.info("网关filter开始,{}",upgradeHeader);
        if (null == upgradeHeader) {
            upgradeHeader = request.getHeader("upgrade");
        }
        if (null != upgradeHeader && "websocket".equalsIgnoreCase(upgradeHeader)) {
//            wrapper.addHeader("connection", "Upgrade");
            ctx.addZuulRequestHeader("connection", "Upgrade");
//            ctx.setRequest(wrapper);
        }
        return null;
    }
}
