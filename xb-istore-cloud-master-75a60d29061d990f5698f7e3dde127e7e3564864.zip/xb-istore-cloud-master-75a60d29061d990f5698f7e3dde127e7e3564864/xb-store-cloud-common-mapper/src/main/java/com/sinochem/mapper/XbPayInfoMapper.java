package com.sinochem.mapper;

import com.sinochem.pojo.XbPayInfo;
import com.sinochem.pojo.XbPayInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface XbPayInfoMapper {
    int insert(XbPayInfo record);

    int insertSelective(XbPayInfo record);

    List<XbPayInfo> selectByExample(XbPayInfoExample example);

    int updateByExampleSelective(@Param("record") XbPayInfo record, @Param("example") XbPayInfoExample example);

    int updateByExample(@Param("record") XbPayInfo record, @Param("example") XbPayInfoExample example);
}