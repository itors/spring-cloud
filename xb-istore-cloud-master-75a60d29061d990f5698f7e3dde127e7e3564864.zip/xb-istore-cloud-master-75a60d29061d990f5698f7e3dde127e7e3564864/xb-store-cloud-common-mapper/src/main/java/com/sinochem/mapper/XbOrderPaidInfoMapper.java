package com.sinochem.mapper;

import com.sinochem.pojo.XbOrderPaidInfo;
import com.sinochem.pojo.XbOrderPaidInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface XbOrderPaidInfoMapper {
    int insert(XbOrderPaidInfo record);

    int insertSelective(XbOrderPaidInfo record);

    List<XbOrderPaidInfo> selectByExample(XbOrderPaidInfoExample example);

    int updateByExampleSelective(@Param("record") XbOrderPaidInfo record, @Param("example") XbOrderPaidInfoExample example);

    int updateByExample(@Param("record") XbOrderPaidInfo record, @Param("example") XbOrderPaidInfoExample example);
}