package com.sinochem.mapper;

import com.sinochem.pojo.XbUser;
import com.sinochem.pojo.XbUserExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface XbUserMapper {
    int insert(XbUser record);

    int insertSelective(XbUser record);

    List<XbUser> selectByExample(XbUserExample example);

    int updateByExampleSelective(@Param("record") XbUser record, @Param("example") XbUserExample example);

    int updateByExample(@Param("record") XbUser record, @Param("example") XbUserExample example);
}