package com.sinochem.order.controller;

import com.sinochem.annotation.SCApi;
import com.sinochem.constant.ApiConstant;
import com.sinochem.order.service.OrderService;
import com.sinochem.pojo.XbResult;
import com.sinochem.pojo.vo.OrderQuery;
import com.sinochem.pojo.vo.UserCart;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 订单 Controller
 *
 * @author liuming
 * @create
 */

@Api(value = "API - orderController", description = "订单 Controller")
@Controller
@RefreshScope
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private OrderService orderService;


    @ApiOperation(value = "生成订单，返回生成订单成功与否", notes = "输入封装的userCart json格式数据")
    @SCApi(name = ApiConstant.ORDER_ADD_ORDER)
    @RequestMapping(value = "/api/v1/order/buildOrder", method = RequestMethod.POST)
    @ResponseBody
    public XbResult addOrder(@RequestBody UserCart userCart) {
        logger.info("ready for order build...");
        logger.info("userCart:{}", userCart.toString());
        XbResult result = orderService.generateOrder(userCart);
        logger.info("order build successfully...");
        return result;
    }


    @ApiOperation(value = "按会话ID，订单状态分页查询 获取订单列表", notes = "输入会话ID，订单状态")
    @SCApi(name = ApiConstant.ORDER_GET_ORDERS)
    @RequestMapping(value = "/api/v1/order/getOrders", method = RequestMethod.POST)
    @ResponseBody
    public XbResult getOrders(@RequestBody OrderQuery orderQuery) {
        logger.info("query for order ...");
        logger.info("sessionId:{}-orderStatus:{}", orderQuery.getSessionId(), orderQuery.getOrderStatus());
        XbResult result = orderService.findOrderList(orderQuery);
        logger.info("query for order successfully...");
        return result;
    }


    @ApiOperation(value = "按orderNo，获取订单", notes = "输入按orderNo，获取订单")
    @SCApi(name = ApiConstant.ORDER_GET_ORDER)
    @RequestMapping(value = "/api/v1/order/getOrder", method = RequestMethod.POST)
    @ResponseBody
    public XbResult getOrder(@RequestBody OrderQuery orderQuery) {

        orderQuery.setiLength(Integer.MAX_VALUE);
        orderQuery.setiStart(0);

        logger.info("query for order ...");
        logger.info("sessionId:{}-orderStatus:{}", orderQuery.getSessionId(), orderQuery.getOrderStatus());
        XbResult result = orderService.findOrderList(orderQuery);

        logger.info("query for order successfully...");
        return result;
    }

    @ApiOperation(value = "按orderNo，删除订单", notes = "输入按orderNo，删除订单")
    @SCApi(name = ApiConstant.ORDER_DEL_ORDER)
    @RequestMapping(value = "/api/v1/order/delOrder", method = RequestMethod.POST)
    @ResponseBody
    public XbResult cancelOrder(@RequestBody OrderQuery orderQuery) {

        XbResult xbResult = orderService.cancelOrderPayByOrderNo(orderQuery);

        return xbResult;
    }
}
