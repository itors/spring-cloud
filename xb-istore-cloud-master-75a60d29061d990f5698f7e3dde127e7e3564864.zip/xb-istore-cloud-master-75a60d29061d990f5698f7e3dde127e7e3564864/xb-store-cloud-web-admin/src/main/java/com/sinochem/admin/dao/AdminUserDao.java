package com.sinochem.admin.dao;

import com.sinochem.mapper.XbAdminUserMapper;
import com.sinochem.pojo.XbAdminUser;
import com.sinochem.pojo.XbAdminUserExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @description: 管理员用户dao
 * @author: liuyuanzhi
 * @create 2018-03-21 下午8:28
 **/
@Repository
public class AdminUserDao {
    @Autowired
    private XbAdminUserMapper xbAdminUserMapper;

    public List<XbAdminUser> selectUserList(String userName, String passWord){
        XbAdminUserExample example = new XbAdminUserExample();
        example.createCriteria().andUserNameEqualTo(userName).andPassWordEqualTo(passWord);

        return xbAdminUserMapper.selectByExample(example);
    }

    public List<XbAdminUser> selectUser(String userName){
        XbAdminUserExample example = new XbAdminUserExample();
        example.createCriteria().andUserNameEqualTo(userName);

        return xbAdminUserMapper.selectByExample(example);
    }
}
