package com.sinochem.admin.controller;

import com.github.pagehelper.PageInfo;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.sinochem.admin.service.OrderService;
import com.sinochem.exception.BasisException;
import com.sinochem.pojo.Response;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.vo.OrderDetailInfo;
import com.sinochem.pojo.vo.OrderInfo;
import com.sinochem.pojo.vo.OrderRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @description: 管理后台,订单相关rest接口
 * @author: liuyuanzhi
 * @create 2018-03-20 上午10:27
 **/
@Api(value = "管理后台orderController api相关",description = "订单查询接口")
@RestController
public class AdminOrderController extends BaseController {
    private final static Logger LOG = LoggerFactory.getLogger(AdminOrderController.class);
    private final static Integer DEFAULT_PAGE = 1;
    private final static Integer DEFAULT_PAGE_SIZE = 100;
    @Autowired
    private OrderService orderService;

    @ApiOperation(value = "订单查询接口",notes = "根据查询项查询订单列表")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/orderList",method={RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public Response queryOrder(@RequestBody OrderRequest order){
        if(order==null){
            return rtnParam(100,"无效的查询");
        }
        if(order.getPage()==null || order.getPage()<=0){
            order.setPage(DEFAULT_PAGE);
        }
        if(order.getPageSize()==null || order.getPageSize()<=0){
            order.setPageSize(DEFAULT_PAGE_SIZE);
        }
        PageInfo<OrderInfo> orderInfoPageInfo = orderService.selectOrderList(order);

        return rtnParam(0,orderInfoPageInfo);
    }

    @ApiOperation(value="订单明细查询接口",notes = "根据查询项查询订单明细列表")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/orderDetailList",method = {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public Response queryOrderDetail(@RequestBody OrderRequest orderRequest){
        if(orderRequest==null){
            return rtnParam(100,"无效的查询");
        }
        if(orderRequest.getPage()==null || orderRequest.getPage()<=0){
            orderRequest.setPage(DEFAULT_PAGE);
        }
        if(orderRequest.getPageSize()==null || orderRequest.getPageSize()<=0){
            orderRequest.setPageSize(DEFAULT_PAGE_SIZE);
        }
        PageInfo<OrderDetailInfo> pageInfo = orderService.selectOrderDetailList(orderRequest);


        return rtnParam(0,pageInfo);
    }


    @ApiOperation(value = "订单查询接口",notes = "根据订单二维码查询订单")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/orderDetail",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryOrder(@RequestBody XbOrder order){
        String orderNo = order.getOrderNo();
        if(StringUtils.isBlank(orderNo) || !StringUtils.isNumeric(orderNo)){
            return  rtnParam(100,"订单编号无效");
        }
        XbOrder orderDetail = orderService.queryOrderByOrderNo(orderNo);
        if(orderDetail==null){
            return rtnParam(200,"没有找到有效订单");
        }
        return rtnParam(0, Lists.newArrayList(new OrderInfo(orderDetail)));
    }

    @ApiOperation(value = "订单验证接口",notes = "查询订单并验货")
    @RequestMapping(value = "/tradeOrder",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response tradeOrder(@RequestBody XbOrder order){
        String orderNo = order.getOrderNo();
        if(StringUtils.isBlank(orderNo) || !StringUtils.isNumeric(orderNo)){
            return rtnParam(300,"无效的订单编号");
        }
        XbOrder tradeOrder = null;
        try{
            tradeOrder = orderService.tradeOrderByOrderNo(orderNo);
        } catch (BasisException e) {
            int errorCode = e.getCode();
            String msg = e.getMsg();
            return rtnParam(errorCode,msg);
        }
        return rtnParam(0,new OrderInfo(tradeOrder));
    }
}
