package com.sinochem.admin.dao;

import com.google.common.collect.Lists;
import com.sinochem.mapper.XbGoodsDeptMapper;
import com.sinochem.mapper.XbGoodsMapper;
import com.sinochem.pojo.XbGoods;
import com.sinochem.pojo.XbGoodsDept;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @description: 商品信息dao
 * @author: liuyuanzhi
 * @create 2018-03-08 上午11:19
 **/
@Repository
public class GoodsDao {
    private final static Logger LOG = LoggerFactory.getLogger(GoodsDao.class);

    @Autowired
    private XbGoodsMapper xbGoodsMapper;
    @Autowired
    private XbGoodsDeptMapper xbGoodsDeptMapper;

    /**
     * 根据店铺查询商品列表
     * @param shopNo
     * @return
     */
    public List<XbGoodsDept> queryGoodsByShopNo(Long shopNo){
        List<XbGoodsDept> list = Lists.newArrayList();
        if(shopNo==null || shopNo<=0){
            return list;
        }
        return xbGoodsDeptMapper.selectGoodsListByShopNo(shopNo);
    }


    /**
     * 根据商品条码和商店编号查询商品信息
     * @param barCode
     * @param shopNo
     * @return
     */
    public XbGoodsDept queryGoodsByBarCode(Long barCode,Long shopNo){
        if(barCode==null || barCode<=0 || shopNo==null || shopNo<=0){
            return null;
        }
        XbGoodsDept queryDto = new XbGoodsDept();
        queryDto.setBarCode(barCode);
        queryDto.setShopNo(shopNo);

        return xbGoodsDeptMapper.selectGoodsByBarCode(queryDto);
    }

    public void insert(List<XbGoods> goodsList){
        for(XbGoods goods: goodsList){
            xbGoodsMapper.insertSelective(goods);
        }
    }

    public void insertGoodsDept(List<XbGoodsDept> goodsDeptList){
        for(XbGoodsDept goodsDept: goodsDeptList){
            xbGoodsDeptMapper.insertSelective(goodsDept);
        }
    }

    public XbGoodsDept selectById(Long id){
        return xbGoodsDeptMapper.selectGoodsById(id);
    }

    public long selectMaxCode(){
        return xbGoodsMapper.selectMaxGoodsCode();
    }

    public List<Long> selectGoodsCodeByBarCode(Long barCode){
        return xbGoodsMapper.selectGoodsCode(barCode);
    }

    public void batchDeleteByGoodsCode(List<Long> goodsCodeList){
        xbGoodsMapper.batchDeleteGoods(goodsCodeList);
    }

    public Long selectGoodsDeptId(Long barCode,Long shopNo){
        if(barCode==null || shopNo==null){
            return null;
        }
        XbGoodsDept goodsDept = new XbGoodsDept();
        goodsDept.setShopNo(shopNo);
        goodsDept.setBarCode(barCode);
        return xbGoodsDeptMapper.selectIdByBarCodeAndShopNo(goodsDept);
    }

    public void batchDeleteGoodsDept(List<Long> idList){
        xbGoodsDeptMapper.batchDeleteGoodsDept(idList);
    }

}
