package com.sinochem.admin.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.sinochem.admin.service.GoodsService;
import com.sinochem.pojo.XbGoods;
import com.sinochem.pojo.XbGoodsDept;
import com.sinochem.admin.dao.GoodsDao;
import com.sinochem.utils.ExcelUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @description: 商品信息
 * @author: liuyuanzhi
 * @create 2018-03-08 上午11:32
 **/
@Service
public class GoodsServiceImpl implements GoodsService {
    private final static Logger LOG = LoggerFactory.getLogger(GoodsServiceImpl.class);
    private final static Long START_VAL = 1000000l;
    @Value("${excel.tempPath}")
    private String tempPath;
    @Value("${goodsCode.key}")
    private String goodsCodeKey;
    @Value("${goodsCode.delta}")
    private Integer goodsCodeDelta;
    @Autowired
    private GoodsDao goodsDao;
    @Autowired
    private RedissonClient redissonClient;

    @Override
    public List<XbGoodsDept> queryGoods(Long shopNo) {

        return goodsDao.queryGoodsByShopNo(shopNo);
    }

    @Override
    public XbGoodsDept queryGoodsByBarCode(Long barCode, Long shopNo) {
        return goodsDao.queryGoodsByBarCode(barCode,shopNo);
    }

    public String importGoods(String fileName, MultipartFile mfile,boolean isGoodsDept){
        File uploadDir = new  File(tempPath);
        //创建一个目录 （它的路径名由当前 File 对象指定，包括任一必须的父路径。）
        if (!uploadDir.exists()) uploadDir.mkdirs();
        //临时文件
        File tempFile = new File(tempPath + new Date().getTime() + ".xlsx");
        InputStream is = null;
        try{
            //将上传的文件写入新建的文件中
            mfile.transferTo(tempFile);
            is = new FileInputStream(tempFile);
            Workbook wb = null;
            //根据文件名判断文件是2003版本还是2007版本
            if(ExcelUtils.isExcel2007(fileName)){
                wb = new XSSFWorkbook(is);
            }else{
                wb = new HSSFWorkbook(is);
            }
            if(isGoodsDept) {
                //根据excel里面的内容读取知识库信息
                return readExcelValue(wb);
            } else {
                return readExcelForGoods(wb);
            }
        }catch(Exception e){
            LOG.error("商品导入异常,{}",fileName,e);
        } finally{
            if(is !=null)
            {
                try{
                    is.close();
                }catch(IOException e){
                    is = null;
                    e.printStackTrace();
                }
            }
        }
        return "导入出错！请检查数据格式！";
    }

    /**
     * 读取sheet内容
     * @param workbook
     * @return
     */
    @Transactional
    public String readExcelValue(Workbook workbook){
        StringBuffer errorMsg = new StringBuffer();
        Sheet sheet = workbook.getSheetAt(0);
        int totalRows = sheet.getPhysicalNumberOfRows();
        int errorCounter = 0;
        if(totalRows<4){
            errorCounter++;
            errorMsg.append("商品信息为空");
        }
        List<XbGoodsDept> goodsDeptList = Lists.newArrayList();
        List<Long> oriIdList = Lists.newArrayList();
        for(int r=4;r<totalRows;r++){
            Row row = sheet.getRow(r);
            if(row==null){
                errorCounter++;
                errorMsg.append("第").append(r+1).append("行数据有问题，请仔细检查!");
                continue;
            }
            try {
                //XbGoods goods = trans2Goods(row);
//                XbGoodsDept goodsDept = trans2GoodsDept(row,oriIdList);
                List<XbGoodsDept> transGoodsList = trans2GoodsDept(row,oriIdList);
                if(transGoodsList.size()==0){
                    errorMsg.append("第").append(r+1).append("行数据无效!");
                    errorCounter++;
                    continue;
                }
                goodsDeptList.addAll(transGoodsList);
            } catch (Exception e){
                e.printStackTrace();
                errorCounter++;
                errorMsg.append("第").append(r+1).append("行数据存在空值或类型错误!");
            }
        }
        //清除已有数据
        if(!CollectionUtils.isEmpty(oriIdList)){
            goodsDao.batchDeleteGoodsDept(oriIdList);
        }
        //导入goodsDpt表
        goodsDao.insertGoodsDept(goodsDeptList);
        errorMsg.append("共导入").append(goodsDeptList.size()).append("条商品信息!");
//        int errorCount = totalRows-4-goodsDeptList.size();
        if(errorCounter>0){
            errorMsg.append("共").append(errorCounter).append("条数据存在错误");
        }
        return errorMsg.toString();
    }

    /**
     * 将row转换成商品实体
     * @param row
     * @return
     */
    private List<XbGoodsDept> trans2GoodsDept(Row row,List<Long> oriIdList){
        List<XbGoodsDept> list = Lists.newArrayList();
        //商品条形码
        Cell barCodeCell = row.getCell(4);
        String barCodeStr = getCellStringValue(barCodeCell);
        String[] barArr = StringUtils.split(barCodeStr,"/");
        if(StringUtils.isBlank(barCodeStr) || barArr.length<1){
            return list;
        }
        Set<String> barSet = Sets.newHashSet(barArr);
        XbGoodsDept goodsDept = new XbGoodsDept();
        //店铺编号
        Cell shopNoCell = row.getCell(2);
        Double shopNo = Double.parseDouble(getCellStringValue(shopNoCell));
        goodsDept.setShopNo(shopNo.longValue());
        //销售价格
        Cell salePriceCell = row.getCell(5);
        goodsDept.setSalePrice(BigDecimal.valueOf(Double.parseDouble(getCellStringValue(salePriceCell))));
        //采购价格
        Cell purchasePriceCell = row.getCell(6);
        if(purchasePriceCell!=null) {
            String purchasePriceStr = getCellStringValue(purchasePriceCell);
            if(StringUtils.isNotBlank(purchasePriceStr) && StringUtils.isNumeric(purchasePriceStr)) {
                goodsDept.setPurchasePrice(BigDecimal.valueOf(Double.parseDouble(purchasePriceStr)));
            }
        }
        //代理商
        Cell departmentCell = row.getCell(7);
        goodsDept.setSaleDepartment(getCellStringValue(departmentCell));
        for(String bar: barSet){
            if(StringUtils.equalsIgnoreCase(bar,"null")){
                continue;
            }
            XbGoodsDept innerGoods = new XbGoodsDept();
            BeanUtils.copyProperties(goodsDept,innerGoods);
            Double barCode = Double.parseDouble(bar);
            innerGoods.setBarCode(barCode.longValue());
            //商品编号
            Long goodsCode = selectGoodsCodeByBarCode(barCode.longValue());
            if(goodsCode==null || goodsCode<=0){
                throw new RuntimeException("请先导入产品信息");
            }
            innerGoods.setGoodsCode(goodsCode);
            //查询商品是否已存在
            Long id = goodsDao.selectGoodsDeptId(barCode.longValue(),shopNo.longValue());
            if(id!=null){
                oriIdList.add(id);
            }
            list.add(innerGoods);
        }

        //Double goodsCode = Double.parseDouble(getCellStringValue(goodsCodeCell));
        //goods.setGoodsCode(goodsCode.longValue());
        //goodsDept.setGoodsCode(goodsCode.longValue());

        //库存
        //Cell stockCell = row.getCell(8);
        //Double stock = Double.parseDouble(getCellStringValue(stockCell));
        //goodsDept.setStock(stock.longValue());
        return list;
    }

    /**
     * 将行转换成产品实体
     * @param row
     * @param oriGoodsCodeList
     * @return
     */
    private List<XbGoods> trans2GoodsEntity(Row row,List<Long> oriGoodsCodeList){
        List<XbGoods> list = Lists.newArrayList();

        //商品条形码
        Cell barCodeCell = row.getCell(2);
        String barCodeStr = getCellStringValue(barCodeCell);
        String[] barArr = StringUtils.split(barCodeStr,"/");
        if(StringUtils.isBlank(barCodeStr) || barArr.length<=0){
            return list;
        }
        Set<String> barSet = Sets.newHashSet(barArr);
        XbGoods goods = new XbGoods();
        //商品名称
        Cell goodsNameCell = row.getCell(1);
        goods.setGoodsName(getCellStringValue(goodsNameCell));
        //商品类型
        Cell catTypeCell = row.getCell(3);
        String catTypeStr = getCellStringValue(catTypeCell);
        if(StringUtils.isBlank(catTypeStr) || !StringUtils.isNumeric(catTypeStr)){
            catTypeStr = "0";
        }
        Double catType = Double.parseDouble(catTypeStr);
        goods.setCategoryType(catType.byteValue());
        //产品图片
        Cell picCell = row.getCell(5);
        if(picCell!=null) {
            String picUrl = getCellStringValue(picCell);
            goods.setMainPicUrl(picUrl);
        }
        for(String bar:barSet){
            if(StringUtils.equalsIgnoreCase(bar,"null")){
                continue;
            }
            XbGoods innerGoods = new XbGoods();
            BeanUtils.copyProperties(goods,innerGoods);
            Double barCode = Double.parseDouble(bar);
            innerGoods.setBarCode(barCode.longValue());

            //查询商品编号
            Long oriGoodsCode = selectGoodsCodeByBarCode(barCode.longValue());
            if(oriGoodsCode!=null && oriGoodsCode>0){
                oriGoodsCodeList.add(oriGoodsCode);
                //oriGoodsCodeList.add(barCode.longValue());
            } else {
                oriGoodsCode  = generateGoodsCode();
            }
            innerGoods.setGoodsCode(oriGoodsCode);
            list.add(innerGoods);
        }
        //商品编号
        //商品简称
//        Cell goodsShortNameCell = row.getCell(3);
//        goods.setShortGoodsName(getCellStringValue(goodsShortNameCell));
        return list;
    }

    /**
     * 获取单元格文本内容
     * @param cell
     * @return
     */
    private String getCellStringValue(Cell cell) {
        String cellValue = "";
        if(cell==null){
            return null;
        }
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_STRING://字符串类型
                cellValue = cell.getStringCellValue();
                if (cellValue.trim().equals("") || cellValue.trim().length() <= 0)
                    cellValue = "";
                break;
            case Cell.CELL_TYPE_NUMERIC://数值类型
                DecimalFormat df = new DecimalFormat("0");
                cellValue = df.format(cell.getNumericCellValue());
                break;
            case Cell.CELL_TYPE_FORMULA://公式
                cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                cellValue = String.valueOf(cell.getNumericCellValue());
                break;
            case Cell.CELL_TYPE_BLANK:
                cellValue = "";
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                break;
            case Cell.CELL_TYPE_ERROR:
                break;
            default:
                break;
        }
        return cellValue;
    }

    /**
     * 根据商品店面表中的id查询数据
     * @param id
     * @return
     */
    public XbGoodsDept selectById(Long id){
        return goodsDao.selectById(id);
    }

    /**
     * 生成产品编号
     * @return
     */
    private long generateGoodsCode(){
        RAtomicLong atomicLong = redissonClient.getAtomicLong(goodsCodeKey);
        if(atomicLong.get()<=START_VAL) {
            long maxCode = goodsDao.selectMaxCode();
            if(maxCode<START_VAL){
                maxCode = START_VAL;
            }
            atomicLong.set(maxCode+goodsCodeDelta);
        }
        return atomicLong.incrementAndGet();
    }


    /**
     * 从excel读入产品信息
     * @param workbook
     * @return
     */
    public String readExcelForGoods(Workbook workbook){
        StringBuffer errorMsg = new StringBuffer();
        Sheet sheet = workbook.getSheetAt(0);
        int totalRows = sheet.getPhysicalNumberOfRows();
        if(totalRows<4){
            errorMsg.append("商品信息为空");
        }
        int errorCounter = 0;
        List<XbGoods> goodsList = Lists.newArrayList();
        List<Long> oriGoodsCodeList = Lists.newArrayList();
        for(int r=4;r<totalRows;r++){
            Row row = sheet.getRow(r);
            if(row==null){
                errorMsg.append("第").append(r+1).append("行数据有问题，请仔细检查!");
                errorCounter++;
                continue;
            }
            try {
                List<XbGoods> transGoodsList = trans2GoodsEntity(row,oriGoodsCodeList);
                if(transGoodsList.size()==0){
                    errorMsg.append("第").append(r+1).append("行数据无效!");
                    errorCounter++;
                    continue;
                }
                goodsList.addAll(transGoodsList);
            } catch (Exception e){
                LOG.error("导入产品信息异常",e);
                errorCounter++;
                errorMsg.append("第").append(r+1).append("行数据存在空值或类型错误!");
            }
        }
        //删除原有数据
        if(!CollectionUtils.isEmpty(oriGoodsCodeList)){
            goodsDao.batchDeleteByGoodsCode(oriGoodsCodeList);
        }
        //导入goods表
        goodsDao.insert(goodsList);
        errorMsg.append("共导入").append(goodsList.size()).append("条商品信息!");
//        int errorCount = totalRows-4-goodsList.size();
        if(errorCounter>0){
            errorMsg.append("共").append(errorCounter).append("条数据存在错误");
        }
        return errorMsg.toString();
    }


    /**
     * 查询条形码已有的产品编码
     * @param barCode
     * @return
     */
    private Long selectGoodsCodeByBarCode(Long barCode){
        List<Long> list = goodsDao.selectGoodsCodeByBarCode(barCode);
        if(list.size()>1){
            LOG.warn("存在多个相同条形码的商品,{}",barCode);
        }
        return list.size()==0?null:list.get(0);
    }


}
