package com.sinochem.admin.dao;

import com.sinochem.mapper.XbOrderDetailMapper;
import com.sinochem.mapper.XbOrderMapper;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.vo.OrderRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/** 订单dao
 * @description:
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:19
 **/
@Repository
public class OrderDao {
    private final static Logger LOG = LoggerFactory.getLogger(OrderDao.class);

    @Autowired
    private XbOrderMapper xbOrderMapper;
    @Autowired
    private XbOrderDetailMapper xbOrderDetailMapper;

    /**
     * 查询订单
     * @param orderNo
     * @return
     */
    public XbOrder selectOrderByOrderNo(String orderNo){
        if(orderNo==null || Long.valueOf(orderNo)<=0){
            return null;
        }
        return xbOrderMapper.selectOrderInfoByOrderNo(orderNo);
    }

    public XbOrder selectOrderForUpdate(String orderNo){
        if(orderNo==null || Long.valueOf(orderNo)<=0){
            return null;
        }

        return xbOrderMapper.selectOrderForUpdate(orderNo);
    }

    public void updateOrder(XbOrder order){
        if(order==null || order.getId()==null || order.getId()<=0){
            throw new RuntimeException("不能更新空订单");
        }
        xbOrderMapper.updateByPrimaryKeySelective(order);
    }

    public List<XbOrder> selectOrderList(OrderRequest request){
        return xbOrderMapper.selectOrderList(request);
    }

    public List<XbOrderDetail> selectOrderDetailList(OrderRequest request){
        return xbOrderDetailMapper.selectOrderDetailList(request);
    }

}
