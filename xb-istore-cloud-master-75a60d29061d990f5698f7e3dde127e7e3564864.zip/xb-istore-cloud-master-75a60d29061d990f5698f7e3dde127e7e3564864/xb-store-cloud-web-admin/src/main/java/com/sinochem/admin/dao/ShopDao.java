package com.sinochem.admin.dao;

import com.sinochem.mapper.XbShopMapper;
import com.sinochem.pojo.XbShop;
import com.sinochem.pojo.XbShopExample;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @description: 店铺dao
 * @author: liuyuanzhi
 * @create 2018-03-07 下午4:40
 **/
@Repository
public class ShopDao {
    private final static Logger LOG = LoggerFactory.getLogger(ShopDao.class);
    @Autowired
    private XbShopMapper xbShopMapper;

    /**
     * 查询所有店铺信息，包含二维码
     * @return
     */
    public List<XbShop> queryQrDataList(){
        return xbShopMapper.selectByExampleWithBLOBs(new XbShopExample());
    }

    /**
     * 查询店铺列表，不含二维码
     * @return
     */
    public List<XbShop> queryShopList(){
        return xbShopMapper.selectByExample(new XbShopExample());
    }

    public XbShop queryShopDetail(Long shopNo){
        if(shopNo==null || shopNo<=0){
            return null;
        }
        XbShopExample example = new XbShopExample();
        example.createCriteria().andShopNoEqualTo(shopNo);
        List<XbShop> shops = xbShopMapper.selectByExample(example);
        return CollectionUtils.isEmpty(shops)?null:shops.get(0);
    }
}
