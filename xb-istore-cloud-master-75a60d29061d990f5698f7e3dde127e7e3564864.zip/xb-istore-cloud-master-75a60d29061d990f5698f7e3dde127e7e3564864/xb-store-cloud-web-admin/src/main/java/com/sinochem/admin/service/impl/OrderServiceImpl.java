package com.sinochem.admin.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.sinochem.exception.BasisException;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.XbShop;
import com.sinochem.admin.dao.OrderDao;
import com.sinochem.admin.dao.ShopDao;
import com.sinochem.admin.service.OrderService;
import com.sinochem.pojo.vo.OrderDetailInfo;
import com.sinochem.pojo.vo.OrderInfo;
import com.sinochem.pojo.vo.OrderRequest;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @description: 订单相关接口实现
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:25
 **/
@Service
public class OrderServiceImpl implements OrderService{
    private final static Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderDao orderDao;
    @Autowired
    private ShopDao shopDao;

    public PageInfo<OrderInfo> selectOrderList(OrderRequest request){
        if(request==null){
            return new PageInfo<>(Lists.newArrayList());
        }
        String startDate = request.getCreateStartDate();
        String endDate = request.getCreateEndDate();
        if(StringUtils.isNotBlank(startDate)){
            request.setCreateStartDate(startDate+" 00:00:00");
        }
        if(StringUtils.isNotBlank(endDate)){
            request.setCreateEndDate(endDate+" 23:59:59");
        }
        PageHelper.startPage(request.getPage(),request.getPageSize());
        PageInfo<XbOrder> xbOrderPageInfo = new PageInfo<>(orderDao.selectOrderList(request));
        List<OrderInfo> orderInfoList = Lists.transform(xbOrderPageInfo.getList(), new Function<XbOrder, OrderInfo>() {
            @Override
            public OrderInfo apply(XbOrder order) {
                return new OrderInfo(order);
            }
        });
        PageInfo<OrderInfo> orderInfoPageInfo = new PageInfo<>(orderInfoList);
        orderInfoPageInfo.setTotal(xbOrderPageInfo.getTotal());
        return orderInfoPageInfo;
    }

    @Override
    public PageInfo<OrderDetailInfo> selectOrderDetailList(OrderRequest request) {
        if(request==null){
            return new PageInfo<>(Lists.newArrayList());
        }
        String startDate = request.getCreateStartDate();
        String endDate = request.getCreateEndDate();
        if(StringUtils.isNotBlank(startDate)){
            request.setCreateStartDate(startDate+" 00:00:00");
        }
        if(StringUtils.isNotBlank(endDate)){
            request.setCreateEndDate(endDate+" 23:59:59");
        }
        PageHelper.startPage(request.getPage(),request.getPageSize());
        PageInfo<XbOrderDetail> xbOrderDetailPageInfo = new PageInfo<>(orderDao.selectOrderDetailList(request));
        List<XbOrderDetail> orderDetailList = xbOrderDetailPageInfo.getList();
        List<OrderDetailInfo> orderDetailInfoList = Lists.transform(orderDetailList, new Function<XbOrderDetail, OrderDetailInfo>() {
            @Override
            public OrderDetailInfo apply(XbOrderDetail orderDetail) {
                return new OrderDetailInfo(orderDetail);
            }
        });
        PageInfo<OrderDetailInfo> orderDetailInfoPageInfo = new PageInfo<>(orderDetailInfoList);
        orderDetailInfoPageInfo.setTotal(xbOrderDetailPageInfo.getTotal());
        return orderDetailInfoPageInfo;
    }

    @Override
    public XbOrder queryOrderByOrderNo(String orderNo) {

        XbOrder order = orderDao.selectOrderByOrderNo(orderNo);
        if(order!=null){
            XbShop shop = shopDao.queryShopDetail(order.getShopNo());
            order.setShop(shop);
        }

        return order;
    }
    @Override
    @Transactional
    public XbOrder tradeOrderByOrderNo(String orderNo) throws BasisException{
        XbOrder order = orderDao.selectOrderForUpdate(orderNo);
        if(order==null){
            return null;
        }
        //校验订单是否已验货
        if(order.getTradeDone()){
            throw new BasisException(100,"订单已验货");
        }
        //校验订单状态是否正常
        if(StringUtils.isBlank(order.getOutTradeNo()) || order.getOrderStatus()!=1){
            throw new BasisException(200,"订单待支付");
        }
        //更新订单状态
        XbOrder updateOrder = new XbOrder();
        updateOrder.setId(order.getId());
        updateOrder.setTradeDone(true);
        orderDao.updateOrder(updateOrder);
        XbShop shop = shopDao.queryShopDetail(order.getShopNo());
        //返回结果
        order.setShop(shop);

        return order;
    }

}
