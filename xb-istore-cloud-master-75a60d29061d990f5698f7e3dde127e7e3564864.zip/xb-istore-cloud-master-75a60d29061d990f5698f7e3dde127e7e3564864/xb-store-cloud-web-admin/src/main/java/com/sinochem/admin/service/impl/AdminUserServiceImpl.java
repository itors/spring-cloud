package com.sinochem.admin.service.impl;

import com.sinochem.admin.dao.AdminUserDao;
import com.sinochem.admin.service.AdminUserService;
import com.sinochem.pojo.XbAdminUser;
import com.sinochem.pojo.vo.UserRequest;
import org.apache.commons.lang.StringUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @description: 管理账号实现
 * @author: liuyuanzhi
 * @create 2018-03-21 下午8:55
 **/
@Service
public class AdminUserServiceImpl implements AdminUserService {
    private final static Logger LOG = LoggerFactory.getLogger(AdminUserServiceImpl.class);
    @Autowired
    private AdminUserDao adminUserDao;
    @Autowired
    private RedissonClient redissonClient;

    public String login(UserRequest userRequest) {
        if (userRequest == null) {
            return null;
        }
        if (StringUtils.isBlank(userRequest.getUserName()) || StringUtils.isBlank(userRequest.getPassWord())) {
            return null;
        }
        List<XbAdminUser> list = adminUserDao.selectUserList(userRequest.getUserName(), userRequest.getPassWord());
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        String signMsg = parseStrToMd5L32(userRequest.getUserName());
        saveToken(signMsg, userRequest.getUserName());
        return signMsg;
    }

    @Override
    public void logout(UserRequest userRequest) {
        RBucket<String> tokenBucket = redissonClient.getBucket(userRequest.getToken());
        tokenBucket.clearExpire();
        tokenBucket.delete();
    }

    public XbAdminUser selectUserInfo(UserRequest userRequest) {
        if (userRequest == null) {
            return null;
        }
        String userName = userRequest.getUserName();
        String token = userRequest.getToken();
        if (StringUtils.isBlank(userName) && StringUtils.isBlank(token)) {
            return null;
        }
        if (StringUtils.isNotBlank(token)) {
            userName = getUser(userRequest.getToken());
        }
        List<XbAdminUser> list = adminUserDao.selectUser(userName);

        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }

    private String parseStrToMd5L32(String userName) {
        String str = System.currentTimeMillis() + userName;
        String reStr = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] bytes = md5.digest(str.getBytes());
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b : bytes) {
                int bt = b & 0xff;
                if (bt < 16) {
                    stringBuffer.append(0);
                }
                stringBuffer.append(Integer.toHexString(bt));
            }
            reStr = stringBuffer.toString();
        } catch (NoSuchAlgorithmException e) {
            LOG.error("使用md5对用户信息加密失败,{},{}", userName, str, e);
        }
        return reStr;
    }

    private void saveToken(String token, String userName) {
        RBucket<String> tokenBucket = redissonClient.getBucket(token);
        String olderVal = tokenBucket.getAndSet(userName);
        if (StringUtils.isNotBlank(olderVal)) {
            LOG.warn("token数据存在重复的值,{},{},{}", token, userName, olderVal);
        }
        tokenBucket.expire(30, TimeUnit.MINUTES);
    }

    public boolean isLogin(String token) {
        return StringUtils.isNotBlank(getUser(token));
    }

    private String getUser(String token) {
        RBucket<String> tokenBucket = redissonClient.getBucket(token);
        String userName = tokenBucket.get();
        if (StringUtils.isNotBlank(userName)) {
            tokenBucket.expire(30, TimeUnit.MINUTES);
        }
        return userName;
    }

}
