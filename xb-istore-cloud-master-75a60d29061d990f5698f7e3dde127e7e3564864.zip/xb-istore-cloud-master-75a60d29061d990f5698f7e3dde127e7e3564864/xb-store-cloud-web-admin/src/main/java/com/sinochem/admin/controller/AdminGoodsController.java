package com.sinochem.admin.controller;

import com.sinochem.admin.service.GoodsService;
import com.sinochem.pojo.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @description: 后台管理系统,商品api接口
 * @author: liuyuanzhi
 * @create 2018-03-20 下午4:37
 **/
@Api(value = "后台管理系统,goodsController API相关",tags = {"goodsController"},description = "商品接口")
@RestController
public class AdminGoodsController extends BaseController{
    private final static Logger LOG = LoggerFactory.getLogger(AdminGoodsController.class);
    @Autowired
    private GoodsService goodsService;

    @ApiOperation(value = "产品导入",notes = "产品(共有信息)导入接口")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/importGoods",method = {RequestMethod.POST})
    @ResponseBody
    public Response importGoods(@RequestParam(value = "filename") MultipartFile file, HttpServletRequest request, HttpServletResponse response){
        String fileName = file.getOriginalFilename();
        String message = goodsService.importGoods(fileName,file,false);
        return rtnParam(0,message+"");
    }

    @ApiOperation(value = "商品导入",notes = "商品导入接口")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/importGoodsDept",method = {RequestMethod.POST})
    @ResponseBody
    public Response importGoodsDept(@RequestParam(value = "filename") MultipartFile file, HttpServletRequest request, HttpServletResponse response){
        String fileName = file.getOriginalFilename();
        String message = goodsService.importGoods(fileName,file,true);
        return rtnParam(0,message+"");
    }
}
