package com.sinochem.admin.service;

import com.sinochem.pojo.XbAdminUser;
import com.sinochem.pojo.vo.UserRequest;

/**
 * @description: 管理账号接口
 * @author: liuyuanzhi
 * @create 2018-03-21 下午8:54
 **/
public interface AdminUserService {
    /**
     * 用户登录
     *
     * @param userRequest
     * @return
     */
    String login(UserRequest userRequest);

    /**
     * 查询用户信息
     *
     * @param userRequest
     * @return
     */
    XbAdminUser selectUserInfo(UserRequest userRequest);

    /**
     * 用户是否登录
     *
     * @param token
     * @return
     */
    boolean isLogin(String token);

    void logout(UserRequest userRequest);
}
