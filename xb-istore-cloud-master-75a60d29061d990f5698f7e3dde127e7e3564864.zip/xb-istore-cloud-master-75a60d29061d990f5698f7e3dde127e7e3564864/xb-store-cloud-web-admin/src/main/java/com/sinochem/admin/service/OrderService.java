package com.sinochem.admin.service;

import com.github.pagehelper.PageInfo;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.vo.OrderDetailInfo;
import com.sinochem.pojo.vo.OrderInfo;
import com.sinochem.pojo.vo.OrderRequest;

import java.util.List;

/**
 * @description: 订单相关service
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:24
 **/
public interface OrderService {
    /**
     * 根据订单编号查询订单
     * @param orderNo
     * @return
     */
    XbOrder queryOrderByOrderNo(String orderNo);

    /**
     * 更新
     * @param orderNo
     * @return
     */
    XbOrder tradeOrderByOrderNo(String orderNo);

    /**
     * 查询订单列表
     * @param request
     * @return
     */
    PageInfo<OrderInfo> selectOrderList(OrderRequest request);

    /**
     * 查询订单详情列表
     * @param request
     * @return
     */
    PageInfo<OrderDetailInfo> selectOrderDetailList(OrderRequest request);

}
