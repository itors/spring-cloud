package com.sinochem.admin.controller;

import com.sinochem.admin.service.AdminUserService;
import com.sinochem.pojo.Response;
import com.sinochem.pojo.XbAdminUser;
import com.sinochem.pojo.vo.AdminUser;
import com.sinochem.pojo.vo.UserRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @description: 后台管理系统用户接口
 * @author: liuyuanzhi
 * @create 2018-03-21 下午9:02
 **/
@Api(value = "管理后台用户管理接口", description = "用户管理接口")
@RestController
public class AdminUserController extends BaseController {
    private final static Logger LOG = LoggerFactory.getLogger(AdminUserController.class);

    @Autowired
    private AdminUserService adminUserService;

    @ApiOperation(value = "用户登录接口", notes="校验用户名和密码")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/userLogin",method = {RequestMethod.OPTIONS,RequestMethod.POST})
    @ResponseBody
    public Response useLogin(@RequestBody UserRequest userRequest) {
        if (userRequest == null) {
            return rtnParam(100, "用户名或密码错误");
        }
        String token = adminUserService.login(userRequest);
        if (StringUtils.isBlank(token)) {
            return rtnParam(200, "用户名或密码错误");
        }
        return rtnParam(0, token);
    }

    @ApiOperation(value = "用户信息查询接口",notes = "查询用户信息")
    @CrossOrigin(value = {"http://localhost:8080","http://localhost:8081"})
    @RequestMapping(value = "/userInfo",method = {RequestMethod.OPTIONS,RequestMethod.POST})
    @ResponseBody
    public Response queryUserInfo(@RequestBody UserRequest userRequest) {
        if (userRequest == null) {
            return rtnParam(100, "没有找到用户信息");
        }
        XbAdminUser adminUser = adminUserService.selectUserInfo(userRequest);
        return rtnParam(0, new AdminUser(adminUser));
    }

    @ApiOperation(value = "用户登出接口", notes = "用户退出系统")
    @CrossOrigin(value = {"http://localhost:8080"})
    @RequestMapping(value = "/userLogout", method = {RequestMethod.OPTIONS, RequestMethod.POST})
    @ResponseBody
    public Response logout(@RequestBody UserRequest userRequest) {
        if (userRequest == null || StringUtils.isBlank(userRequest.getToken())) {
            return rtnParam(100, "没有找到用户信息");
        }
        adminUserService.logout(userRequest);
        return rtnParam(0, null);
    }
}
