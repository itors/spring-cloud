package com.sinochem.admin.controller;

/**
 * @description:
 * @author: liuyuanzhi
 * @create 2018-03-27 上午9:52
 **/
public class AdminWebSocketController {
}
