package com.sinochem.admin;

import com.sinochem.admin.intercept.UserInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @description: 后台管理系统拦截器
 * @author: liuyuanzhi
 * @create 2018-03-21 下午5:49
 **/
@Configuration
public class AdminInterceptor extends WebMvcConfigurerAdapter{
    private final static Logger LOG = LoggerFactory.getLogger(AdminInterceptor.class);

    @Autowired
    private UserInterceptor userInterceptor;
    /**
     * 添加拦截器
     * @param registry
     */
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userInterceptor)
                //添加需要验证登录用户操作权限的请求
                .addPathPatterns("/order*");
    }
}
