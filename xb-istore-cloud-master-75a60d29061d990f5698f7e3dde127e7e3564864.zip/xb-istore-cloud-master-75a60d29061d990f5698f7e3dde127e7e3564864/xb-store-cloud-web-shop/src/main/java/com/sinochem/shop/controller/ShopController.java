package com.sinochem.shop.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.sinochem.pojo.Response;
import com.sinochem.pojo.XbGoodsDept;
import com.sinochem.pojo.XbShop;
import com.sinochem.pojo.vo.Goods;
import com.sinochem.shop.service.GoodsService;
import com.sinochem.shop.service.ShopService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @description: 商店api接口
 * @author: liuyuanzhi
 * @create 2018-03-07 下午4:37
 **/
@Api(value = "shopController API相关",tags = {"shopController"},description = "商店接口")
@RestController
public class ShopController extends BaseController{
    private final static Logger LOG = LoggerFactory.getLogger(ShopController.class);
    @Autowired
    private ShopService shopService;
    @Autowired
    private GoodsService goodsService;

    @ApiOperation(value = "查询商店列表",notes = "查询商店列表接口")
    @RequestMapping(value = "/shopList",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryShops(){
        List<XbShop> shops = shopService.queryShops();
        if(CollectionUtils.isEmpty(shops)){
            return rtnParam(100,"没有查到有效店铺");
        }
        return rtnParam(0,shops);
    }

    @ApiOperation(value = "查询商店列表-包含原始二维码信息",notes = "包含二维码的商店列表查询接口")
    @RequestMapping(value = "/shopQrList", method = {RequestMethod.GET,RequestMethod.POST}, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryQrShops(){
        List<XbShop> shops = shopService.queryQrShops();
        if(CollectionUtils.isEmpty(shops)){
            return rtnParam(100,"没有查到有效店铺");
        }
        return rtnParam(0,shops);
    }

    @ApiOperation(value = "查询店铺详情",notes = "查询店铺详情接口")
    @RequestMapping(value = "/shopDetail",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryShopDetail(@ApiParam(name = "shopNo",value = "店铺编号")@RequestBody XbShop xbShop){
        Long shopNo = xbShop.getShopNo();
        if(shopNo==null || shopNo<=0){
            return rtnParam(200,"店铺编号为空");
        }
        XbShop shopDetail = shopService.queryShopDetail(shopNo);
        if(shopDetail==null){
            return rtnParam(100,"没有找到店铺信息");
        }

        return rtnParam(0,shopDetail);
    }

    @ApiOperation(value = "查询店铺对应的产品列表",notes = "店铺产品列表查询接口")
    @RequestMapping(value = "/goodsList",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryProductsByShopNo(@ApiParam(name = "shopNo",value = "店铺编号") @RequestBody XbGoodsDept goods){
        Long shopNo = goods.getShopNo();
        if(shopNo==null || shopNo<=0){
            return rtnParam(200,"店铺编号为空");
        }
        List<XbGoodsDept> goodsList = goodsService.queryGoods(shopNo);
        if(CollectionUtils.isEmpty(goodsList)){
            return rtnParam(100,"该店铺下没有找到有效商品");
        }

        List<Goods> voList = Lists.transform(goodsList, new Function<XbGoodsDept, Goods>() {
            @Override
            public Goods apply(XbGoodsDept goodsDept) {
                return new Goods(goodsDept);
            }
        });
        return rtnParam(0,voList);
    }

    @ApiOperation(value = "店铺商品详情查询",notes = "店铺商品详情查询接口")
    @RequestMapping(value = "/goodsDetail", method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryProduct(@ApiParam(name = "shopNo 和 barCode",value = "店铺编号和商品条码")@RequestBody XbGoodsDept goods){
        Long shopNo = goods.getShopNo();
        if(shopNo==null || shopNo<=0){
            return rtnParam(200,"商店编号为空");
        }
        Long barCode = goods.getBarCode();
        if(barCode==null || barCode<=0){
            return rtnParam(200,"商品条形码为空");
        }

        XbGoodsDept goodsDetail = goodsService.queryGoodsByBarCode(barCode,shopNo);
        if(goodsDetail==null){
            return rtnParam(100,"没有找到商品信息");
        }

        return rtnParam(0,new Goods(goodsDetail));
    }

    @ApiOperation(value = "产品导入",notes = "产品(共有信息)导入接口")
    @RequestMapping(value = "/importGoods",method = {RequestMethod.POST})
    @ResponseBody
    public Response importGoods(@RequestParam(value = "filename") MultipartFile file, HttpServletRequest request, HttpServletResponse response){
        String fileName = file.getOriginalFilename();
        String message = goodsService.importGoods(fileName,file,false);
        return rtnParam(0,message+"");
    }

    @ApiOperation(value = "商品导入",notes = "商品导入接口")
    @RequestMapping(value = "/importGoodsDept",method = {RequestMethod.POST})
    @ResponseBody
    public Response importGoodsDept(@RequestParam(value = "filename") MultipartFile file, HttpServletRequest request, HttpServletResponse response){
        String fileName = file.getOriginalFilename();
        String message = goodsService.importGoods(fileName,file,true);
        return rtnParam(0,message+"");
    }
}
