package com.sinochem.shop.controller;

import com.sinochem.pojo.Response;
import com.sinochem.pojo.vo.UserRequest;
import com.sinochem.shop.service.WebSocketService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @description: websocket认证接口
 * @author: liuyuanzhi
 * @create 2018-03-27 上午10:46
 **/
@Api(value = "websocket api相关",description = "websocket入口")
@RestController
public class WebSocketController extends BaseController{
    private final static Logger LOG = LoggerFactory.getLogger(WebSocketController.class);
    @Autowired
    private WebSocketService webSocketService;

    @ApiOperation(value = "websocket认证",notes = "对oauth的token和用户名鉴权")
    @RequestMapping(value = "/webSocketLogin",method = {RequestMethod.POST})
    @ResponseBody
    public Response webSocketLogin(@RequestBody UserRequest userRequest){
        if(userRequest==null|| StringUtils.isBlank(userRequest.getToken()) || StringUtils.isBlank(userRequest.getUserName())){
            return rtnParam(100,"认证信息错误");
        }
        boolean isSuccess = webSocketService.login(userRequest);
        if(!isSuccess){
            return rtnParam(200,"认证失败");
        }

        return rtnParam(0,userRequest.getToken());
    }
}
