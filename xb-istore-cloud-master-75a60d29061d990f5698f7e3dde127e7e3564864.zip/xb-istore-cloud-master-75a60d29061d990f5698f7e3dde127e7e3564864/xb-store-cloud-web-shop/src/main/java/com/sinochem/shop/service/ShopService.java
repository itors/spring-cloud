package com.sinochem.shop.service;

import com.sinochem.pojo.XbShop;

import java.util.List;

/**
 * @description: 店铺接口声明
 * @author: liuyuanzhi
 * @create 2018-03-07 下午4:35
 **/
public interface ShopService {
    /**
     * 查询所有店铺信息
     * @return
     */
    public List<XbShop> queryShops();

    /**
     * 查询店铺列表，包含店铺二维码
     * @return
     */
    public List<XbShop> queryQrShops();

    /**
     * 查询店铺详情
     * @param shopNo
     * @return
     */
    public XbShop queryShopDetail(Long shopNo);
}
