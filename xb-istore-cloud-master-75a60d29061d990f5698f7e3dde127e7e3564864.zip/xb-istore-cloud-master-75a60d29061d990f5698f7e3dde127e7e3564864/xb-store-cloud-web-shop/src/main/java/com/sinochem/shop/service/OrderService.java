package com.sinochem.shop.service;

import com.sinochem.pojo.XbOrder;

/**
 * @description: 订单相关service
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:24
 **/
public interface OrderService {
    /**
     * 根据订单编号查询订单
     * @param orderNo
     * @return
     */
    XbOrder queryOrderByOrderNo(String orderNo);

    /**
     * 更新
     * @param orderNo
     * @return
     */
    XbOrder tradeOrderByOrderNo(String orderNo);
}
