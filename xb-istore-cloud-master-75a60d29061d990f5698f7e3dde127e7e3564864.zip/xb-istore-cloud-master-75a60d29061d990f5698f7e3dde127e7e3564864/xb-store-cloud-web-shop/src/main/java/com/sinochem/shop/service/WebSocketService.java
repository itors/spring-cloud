package com.sinochem.shop.service;

import com.sinochem.pojo.vo.UserRequest;

/**
 * @description: websocket接口
 * @author: liuyuanzhi
 * @create 2018-03-27 上午10:44
 **/
public interface WebSocketService {
    /**
     * websocket认证
     * @param userRequest
     * @return
     */
    boolean login(UserRequest userRequest);

    /**
     * 移除websocket标识
     * @param token
     * @return
     */
    boolean removeToken(String token);

    /**
     * 获取认证用户
     * @param token
     * @return
     */
    String getLoginInfo(String token);
}
