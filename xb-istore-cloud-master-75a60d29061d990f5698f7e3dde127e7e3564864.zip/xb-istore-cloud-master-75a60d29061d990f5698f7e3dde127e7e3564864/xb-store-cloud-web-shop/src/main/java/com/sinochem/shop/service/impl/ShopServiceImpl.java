package com.sinochem.shop.service.impl;

import com.sinochem.pojo.XbShop;
import com.sinochem.shop.dao.ShopDao;
import com.sinochem.shop.service.ShopService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description: 店铺service
 * @author: liuyuanzhi
 * @create 2018-03-07 下午4:38
 **/
@Service
public class ShopServiceImpl implements ShopService{
    private final static Logger LOG = LoggerFactory.getLogger(ShopServiceImpl.class);
    @Autowired
    private ShopDao shopDao;

    public List<XbShop> queryShops(){
        return shopDao.queryShopList();
    }

    public List<XbShop> queryQrShops(){
        return shopDao.queryQrDataList();
    }

    @Override
    public XbShop queryShopDetail(Long shopNo) {
        return shopDao.queryShopDetail(shopNo);
    }
}
