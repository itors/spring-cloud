package com.sinochem.shop;

import com.sinochem.shop.handler.WebSocketHandler;
import com.sinochem.shop.interceptor.WebSocketInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/**
 * @description: websocket配置
 * @author: liuyuanzhi
 * @create 2018-03-27 下午12:04
 **/
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer{
    @Autowired
    private WebSocketInterceptor webSocketInterceptor;
    @Autowired
    private WebSocketHandler webSocketHandler;
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry webSocketHandlerRegistry) {
        webSocketHandlerRegistry.addHandler(webSocketHandler,"/startWebSocket").addInterceptors(webSocketInterceptor).setAllowedOrigins("*");
    }
}
