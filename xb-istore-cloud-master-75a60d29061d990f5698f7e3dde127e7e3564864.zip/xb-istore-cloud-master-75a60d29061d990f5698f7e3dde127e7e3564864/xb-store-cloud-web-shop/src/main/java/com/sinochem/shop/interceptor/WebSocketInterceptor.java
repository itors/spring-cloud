package com.sinochem.shop.interceptor;

import com.sinochem.shop.Constant;
import com.sinochem.shop.service.WebSocketService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Map;

/**
 * @description: websocket拦截器
 * @author: liuyuanzhi
 * @create 2018-03-27 上午11:58
 **/
@Component
public class WebSocketInterceptor implements HandshakeInterceptor{
    private final static Logger LOG = LoggerFactory.getLogger(WebSocketInterceptor.class);
    @Autowired
    private WebSocketService webSocketService;

    @Override
    public boolean beforeHandshake(ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse, WebSocketHandler webSocketHandler, Map<String, Object> map) throws Exception {
        if(serverHttpRequest instanceof ServletServerHttpRequest){
            ServletServerHttpRequest request = (ServletServerHttpRequest) serverHttpRequest;
            String token = request.getServletRequest().getParameter(Constant.WEB_SOCKET_USER);
            String loginInfo = webSocketService.getLoginInfo(token);
            if(StringUtils.isNotBlank(loginInfo)){
                map.put(Constant.WEB_SOCKET_USER,loginInfo);
            }
        }
        return true;
    }

    @Override
    public void afterHandshake(ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse, WebSocketHandler webSocketHandler, Exception e) {
    }
}
