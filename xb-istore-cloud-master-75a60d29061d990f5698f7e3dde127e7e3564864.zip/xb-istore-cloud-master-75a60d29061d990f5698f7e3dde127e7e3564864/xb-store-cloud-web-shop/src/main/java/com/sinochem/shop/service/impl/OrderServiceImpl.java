package com.sinochem.shop.service.impl;

import com.sinochem.exception.BasisException;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbShop;
import com.sinochem.shop.dao.OrderDao;
import com.sinochem.shop.dao.ShopDao;
import com.sinochem.shop.service.OrderService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @description: 订单相关接口实现
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:25
 **/
@Service
public class OrderServiceImpl implements OrderService{
    private final static Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderDao orderDao;
    @Autowired
    private ShopDao shopDao;
    @Override
    public XbOrder queryOrderByOrderNo(String orderNo) {

        XbOrder order = orderDao.selectOrderByOrderNo(orderNo);
        if(order!=null){
            XbShop shop = shopDao.queryShopDetail(order.getShopNo());
            order.setShop(shop);
        }

        return order;
    }
    @Override
    @Transactional
    public XbOrder tradeOrderByOrderNo(String orderNo) throws BasisException{
        XbOrder order = orderDao.selectOrderForUpdate(orderNo);
        if(order==null){
            return null;
        }
        //校验订单是否已验货
        if(order.getTradeDone()){
            throw new BasisException(100,"订单已验货");
        }
        //校验订单状态是否正常
        if(StringUtils.isBlank(order.getOutTradeNo()) || order.getOrderStatus()!=1){
            throw new BasisException(200,"订单待支付");
        }
        //更新订单状态
        XbOrder updateOrder = new XbOrder();
        updateOrder.setId(order.getId());
        updateOrder.setTradeDone(true);
        orderDao.updateOrder(updateOrder);
        XbShop shop = shopDao.queryShopDetail(order.getShopNo());
        //返回结果
        order.setShop(shop);

        return order;
    }
}
