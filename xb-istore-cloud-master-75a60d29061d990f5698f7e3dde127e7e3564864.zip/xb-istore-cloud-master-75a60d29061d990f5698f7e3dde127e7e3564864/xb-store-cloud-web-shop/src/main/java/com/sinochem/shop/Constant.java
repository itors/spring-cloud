package com.sinochem.shop;

/**
 * @description: 店铺模块常量
 * @author: liuyuanzhi
 * @create 2018-03-27 上午10:05
 **/
public class Constant {
    public final static String WEB_SOCKET_KEY = "order_web_socket";
    public final static String WEB_SOCKET_USER = "access_token";
}
