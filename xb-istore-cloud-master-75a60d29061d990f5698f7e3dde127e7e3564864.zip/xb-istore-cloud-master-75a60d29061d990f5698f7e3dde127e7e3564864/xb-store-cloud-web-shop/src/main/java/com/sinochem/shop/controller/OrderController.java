package com.sinochem.shop.controller;

import com.alibaba.fastjson.JSON;
import com.sinochem.exception.BasisException;
import com.sinochem.pojo.Response;
import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.vo.OrderInfo;
import com.sinochem.shop.Constant;
import com.sinochem.shop.handler.WebSocketHandler;
import com.sinochem.shop.service.OrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @description: 订单相关rest接口
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:27
 **/
@Api(value = "orderController api相关",description = "订单查询接口")
@RestController
public class OrderController extends BaseController {
    private final static Logger LOG = LoggerFactory.getLogger(OrderController.class);
    @Autowired
    private OrderService orderService;
    @Autowired
    private WebSocketHandler webSocketHandler;

    @ApiOperation(value = "订单查询接口",notes = "根据订单二维码查询订单")
    @RequestMapping(value = "/orderDetail",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response queryOrder(@RequestBody XbOrder order){
        String orderNo = order.getOrderNo();
        if(StringUtils.isBlank(orderNo) || !StringUtils.isNumeric(orderNo)){
            return  rtnParam(100,"订单编号无效");
        }
        XbOrder orderDetail = orderService.queryOrderByOrderNo(orderNo);
        if(orderDetail==null){
            return rtnParam(200,"没有找到有效订单");
        }
        return rtnParam(0,new OrderInfo(orderDetail));
    }

    @ApiOperation(value = "订单验证接口",notes = "查询订单并验货")
    @RequestMapping(value = "/tradeOrder",method = {RequestMethod.GET,RequestMethod.POST},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response tradeOrder(@RequestBody XbOrder order, HttpServletRequest request){
        String orderNo = order.getOrderNo();
        if(StringUtils.isBlank(orderNo) || !StringUtils.isNumeric(orderNo)){
            return rtnParam(300,"无效的订单编号");
        }
        XbOrder tradeOrder = null;
        try{
            tradeOrder = orderService.tradeOrderByOrderNo(orderNo);
        } catch (BasisException e) {
            int errorCode = e.getCode();
            String msg = e.getMsg();
            return rtnParam(errorCode,msg);
        }
        if(tradeOrder==null){
            return rtnParam(300,"无效的订单编号");
        }
        String token = request.getParameter(Constant.WEB_SOCKET_USER);
        LOG.info("验货的用户token是:{}",token);
        OrderInfo orderInfo = new OrderInfo(tradeOrder);
        webSocketHandler.sendMsgToUser(token,JSON.toJSONString(order));
//        webSocketHandler.sendMsgToUsers(JSON.toJSONString(order));
        return rtnParam(0,orderInfo);
    }
}
