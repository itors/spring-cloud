package com.sinochem.shop.controller;


import com.sinochem.pojo.Response;

public abstract class BaseController {
    protected Response rtnParam(Integer errorCode, Object data){
        if (errorCode.intValue() == 0) {
            return new Response(data);
        } else {
            return new Response(errorCode,data.toString());
        }
    }
}
