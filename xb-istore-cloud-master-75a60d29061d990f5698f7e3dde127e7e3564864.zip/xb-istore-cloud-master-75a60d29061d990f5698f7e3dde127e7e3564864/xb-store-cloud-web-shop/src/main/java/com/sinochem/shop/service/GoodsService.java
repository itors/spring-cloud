package com.sinochem.shop.service;

import com.sinochem.pojo.XbGoods;
import com.sinochem.pojo.XbGoodsDept;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @description: 商品信息service
 * @author: liuyuanzhi
 * @create 2018-03-08 上午11:32
 **/
public interface GoodsService {
    /**
     * 根据商店编号查询商品列表
     * @param shopNo
     * @return
     */
    List<XbGoodsDept> queryGoods(Long shopNo);

    /**
     * 根据商品条形码查询商品详情
     * @param barCode
     * @param shopNo
     * @return
     */
    XbGoodsDept queryGoodsByBarCode(Long barCode,Long shopNo);

    /**
     * excel导入商品
     * @param fileName
     * @param mfile
     * @param isGoodsDept
     * @return
     */
    String importGoods(String fileName, MultipartFile mfile, boolean isGoodsDept);

    /**
     * 根据id获取数据，测试用
     * @param id
     * @return
     */
    XbGoodsDept selectById(Long id);
}
