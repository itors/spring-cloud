package com.sinochem.shop.handler;

import com.google.common.collect.Maps;
import com.sinochem.shop.Constant;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.Map;

/**
 * @description: websocket处理类
 * @author: liuyuanzhi
 * @create 2018-03-27 上午11:06
 **/
@Component
public class WebSocketHandler extends TextWebSocketHandler{
    private final static Logger LOG = LoggerFactory.getLogger(WebSocketHandler.class);
    private final static Map<String,WebSocketSession> userMap = Maps.newConcurrentMap();

    @Override
    public void afterConnectionClosed(WebSocketSession socketSession, CloseStatus status){
        userMap.remove(getUserToken(socketSession));
    }

    @Override
    public void handleTransportError(WebSocketSession socketSession,Throwable throwable) throws IOException {
        if(socketSession.isOpen()){
            socketSession.close();
        }
        userMap.remove(getUserToken(socketSession));
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws IOException {
        String user = getUserToken(session);
        LOG.info("成功建立连接,{}",user);
        if(StringUtils.isBlank(user)){
            LOG.error("用户标识为空,无法使用新建的连接");
        } else {
            userMap.put(user,session);
        }

    }

    @Override
    protected void handleTextMessage(WebSocketSession socketSession,TextMessage message) throws Exception {
        LOG.info("websocket收到信息:{},{}",new String(message.asBytes()),getUserToken(socketSession));
        super.handleTextMessage(socketSession,message);
    }

    public boolean sendMsgToUser(String user,String message){
        if(userMap.get(user) == null){
            LOG.warn("无法发送信息,没有找到用户,{}",user);
            return false;
        }
        WebSocketSession socketSession = userMap.get(user);
        if(!socketSession.isOpen()){
            LOG.warn("连接已关闭,{}",user);
            return false;
        }
        try {
            socketSession.sendMessage(new TextMessage(message));
        } catch (IOException e) {
            LOG.error("发送信息异常,{},{}",user,message,e);
            return false;
        }
        return true;
    }

    @Async
    public boolean sendMsgToUsers(String msgInfo){
        boolean isSuccess = true;
        TextMessage textMessage = new TextMessage(msgInfo);
        for(Map.Entry<String,WebSocketSession> entry: userMap.entrySet()){
            try{
                WebSocketSession session = entry.getValue();
                if(session.isOpen()){
                    session.sendMessage(textMessage);
                }
            } catch (IOException e){
                LOG.error("发送用户信息失败,{},{}",entry.getKey(),msgInfo);
                isSuccess = false;
            }
        }

        return isSuccess;
    }

    private String getUserToken(WebSocketSession socketSession){
        return (String) socketSession.getAttributes().get(Constant.WEB_SOCKET_USER);
    }
}
