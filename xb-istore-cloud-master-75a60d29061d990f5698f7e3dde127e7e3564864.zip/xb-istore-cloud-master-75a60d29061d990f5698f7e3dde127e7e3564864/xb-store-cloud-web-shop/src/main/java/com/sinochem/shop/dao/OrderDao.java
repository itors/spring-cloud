package com.sinochem.shop.dao;

import com.sinochem.mapper.XbOrderMapper;
import com.sinochem.pojo.XbOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** 订单dao
 * @description:
 * @author: liuyuanzhi
 * @create 2018-03-09 上午10:19
 **/
@Repository
public class OrderDao {
    private final static Logger LOG = LoggerFactory.getLogger(OrderDao.class);

    @Autowired
    private XbOrderMapper xbOrderMapper;

    /**
     * 查询订单
     * @param orderNo
     * @return
     */
    public XbOrder selectOrderByOrderNo(String orderNo){
        if(orderNo==null || Long.valueOf(orderNo)<=0){
            return null;
        }
        return xbOrderMapper.selectOrderInfoByOrderNo(orderNo);
    }

    public XbOrder selectOrderForUpdate(String orderNo){
        if(orderNo==null || Long.valueOf(orderNo)<=0){
            return null;
        }

        return xbOrderMapper.selectOrderForUpdate(orderNo);
    }

    public void updateOrder(XbOrder order){
        if(order==null || order.getId()==null || order.getId()<=0){
            throw new RuntimeException("不能更新空订单");
        }
        xbOrderMapper.updateByPrimaryKeySelective(order);
    }

}
