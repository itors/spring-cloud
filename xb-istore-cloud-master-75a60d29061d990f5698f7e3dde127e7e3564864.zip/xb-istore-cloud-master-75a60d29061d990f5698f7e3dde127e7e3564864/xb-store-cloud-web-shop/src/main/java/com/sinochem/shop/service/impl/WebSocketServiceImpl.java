package com.sinochem.shop.service.impl;

import com.sinochem.pojo.vo.UserRequest;
import com.sinochem.shop.Constant;
import com.sinochem.shop.service.WebSocketService;
import org.apache.commons.lang.StringUtils;
import org.redisson.api.RMapCache;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @description: websocket接口实现
 * @author: liuyuanzhi
 * @create 2018-03-27 上午10:11
 **/
@Service
public class WebSocketServiceImpl implements WebSocketService{
    private final static Logger LOG = LoggerFactory.getLogger(WebSocketServiceImpl.class);
    @Autowired
    private RedissonClient redissonClient;

    public boolean login(UserRequest userRequest){
        if(userRequest==null||StringUtils.isBlank(userRequest.getToken()) || StringUtils.isBlank(userRequest.getUserName())){
            LOG.error("websocket登录信息为空");
            return false;
        }
        return saveLoginInfo(userRequest);
    }

    /**
     * 记录用户连接信息
     * @param userRequest
     * @return
     */
    private boolean saveLoginInfo(UserRequest userRequest){
        RMapCache<String,String> loginMap = redissonClient.getMapCache(Constant.WEB_SOCKET_KEY);
        String preUserName = loginMap.get(userRequest.getToken());
        if(StringUtils.isNotBlank(preUserName)){
            LOG.warn("用户重新进行websocket连接,{},{},{}",userRequest.getToken(),userRequest.getUserName(),preUserName);
        }
        loginMap.put(userRequest.getToken(),userRequest.getUserName(),60, TimeUnit.MINUTES);
        return true;
    }

    public boolean removeToken(String token){
        RMapCache<String,String> loginMap = redissonClient.getMapCache(Constant.WEB_SOCKET_KEY);
        String loginUser = loginMap.get(token);
        if(StringUtils.isBlank(loginUser)){
            LOG.warn("websocket已断开,token:{}",token);
        }
        return true;
    }

    public String getLoginInfo(String token){
        RMapCache<String,String> loginMap = redissonClient.getMapCache(Constant.WEB_SOCKET_KEY);
        String userName = loginMap.get(token);
        if(StringUtils.isBlank(userName)){
            LOG.warn("websocket验证失败,{}",token);
            return null;
        }
        loginMap.put(token,userName,60,TimeUnit.MINUTES);
        return token;
    }
}
