package com.sinochem.pojo;

import java.util.Date;

public class XbAccessLogs {
    private Long id;

    private String apiName;

    private String uri;

    private Date accessDate;

    private String reqParam;

    private String resParam;

    private String exp;

    public XbAccessLogs(Long id, String apiName, String uri, Date accessDate, String reqParam, String resParam, String exp) {
        this.id = id;
        this.apiName = apiName;
        this.uri = uri;
        this.accessDate = accessDate;
        this.reqParam = reqParam;
        this.resParam = resParam;
        this.exp = exp;
    }

    public XbAccessLogs() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName == null ? null : apiName.trim();
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri == null ? null : uri.trim();
    }

    public Date getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(Date accessDate) {
        this.accessDate = accessDate;
    }

    public String getReqParam() {
        return reqParam;
    }

    public void setReqParam(String reqParam) {
        this.reqParam = reqParam == null ? null : reqParam.trim();
    }

    public String getResParam() {
        return resParam;
    }

    public void setResParam(String resParam) {
        this.resParam = resParam == null ? null : resParam.trim();
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp == null ? null : exp.trim();
    }
}