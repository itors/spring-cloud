package com.sinochem.pojo.vo;

import java.io.Serializable;

public class OrderQuery implements Serializable {
    private String sessionId;

    private Integer orderStatus;
    private Integer iStart;
    private Integer iLength;

    private Boolean tradeDone = null;

    private String orderNo;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Boolean getTradeDone() {
        return tradeDone;
    }

    public void setTradeDone(Boolean tradeDone) {
        this.tradeDone = tradeDone;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getiStart() {
        return iStart;
    }

    public void setiStart(Integer iStart) {
        this.iStart = iStart;
    }

    public Integer getiLength() {
        return iLength;
    }

    public void setiLength(Integer iLength) {
        this.iLength = iLength;
    }
}
