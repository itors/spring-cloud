package com.sinochem.pojo.vo;

import com.sinochem.pojo.XbAdminUser;

/**
 * @description: 后台用户vo
 * @author: liuyuanzhi
 * @create 2018-03-22 上午11:47
 **/
public class AdminUser {
    //登录用户名
    private String userName;
    //真实用户名
    private String realName;
    //用户昵称
    private String nickName;
    //用户角色
    private String role;
    //联系电话
    private String mobile;
    //邮箱
    private String email;
    //备注
    private String remark;
    //创建日期
    private Long createTime;
    //修改日期
    private Long updateTime;

    public AdminUser(XbAdminUser adminUser){
        if(adminUser==null){
            return;
        }
        this.userName = adminUser.getUserName();
        this.realName = adminUser.getRealName();
        this.nickName = adminUser.getNickName();
        this.role = adminUser.getRole();
        this.mobile = adminUser.getMobile();
        this.email = adminUser.getEmail();
        this.createTime = adminUser.getCreateTime().getTime();
        this.updateTime = adminUser.getUpdateTime().getTime();
    }
    public AdminUser() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
}
