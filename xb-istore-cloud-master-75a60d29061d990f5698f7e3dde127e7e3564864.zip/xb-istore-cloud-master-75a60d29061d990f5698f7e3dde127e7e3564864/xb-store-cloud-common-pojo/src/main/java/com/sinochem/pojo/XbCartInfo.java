package com.sinochem.pojo;


import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 购物车 pojo
 *
 * @author liuming
 * @create
 */
public class XbCartInfo implements Serializable {

    private Long id;

    /*商店编码*/
    private Long shopNo;
    /*商品编码*/
    private Long goodsCode;
    /*商品名称*/
    private String goodsName;
    /*图片*/
    private String picUrl;
    /*商品售价*/
    private BigDecimal salePrice;
    /*数量*/
    private Integer count;
    /*总价*/
    private BigDecimal sum;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGoodsCode() {
        return goodsCode;
    }

    public void setGoodsCode(Long goodsCode) {
        this.goodsCode = goodsCode;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public BigDecimal getSum() {
        return sum;
    }

    public void setSum(BigDecimal sum) {
        this.sum = sum;
    }

    public Long getShopNo() {
        return shopNo;
    }

    public void setShopNo(Long shopNo) {
        this.shopNo = shopNo;
    }
}
