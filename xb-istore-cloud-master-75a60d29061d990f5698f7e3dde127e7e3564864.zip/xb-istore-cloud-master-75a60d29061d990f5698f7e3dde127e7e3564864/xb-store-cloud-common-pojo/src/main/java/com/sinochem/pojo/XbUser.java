package com.sinochem.pojo;

import java.util.Date;
import java.util.Map;

public class XbUser {
    private Long id;

    private String appId;

    private String password;

    private String realName;

    private String nickName;

    private Boolean gender;

    private String avatarUrl;

    private String signature;

    private String openId;

    private String unionId;

    private Date birthday;

    private String address;

    private Date createDate;

    private Date updateDate;

    private Date lastLoginDate;

    private Boolean disabled;

    private String phone;

    private Boolean isPhoneActive;

    private String email;

    private Boolean isEmailActive;

    private String language;

    private String city;

    private String province;

    private String country;

    private Map watermark;

    public Map getWatermark() {
        return watermark;
    }

    public void setWatermark(Map watermark) {
        this.watermark = watermark;
    }

    public XbUser(Long id, String appId, String password, String realName, String nickName, Boolean gender, String avatarUrl, String signature, String openId, String unionId, Date birthday, String address, Date createDate, Date updateDate, Date lastLoginDate, Boolean disabled, String phone, Boolean isPhoneActive, String email, Boolean isEmailActive, String language, String city, String province, String country) {
        this.id = id;
        this.appId = appId;
        this.password = password;
        this.realName = realName;
        this.nickName = nickName;
        this.gender = gender;
        this.avatarUrl = avatarUrl;
        this.signature = signature;
        this.openId = openId;
        this.unionId = unionId;
        this.birthday = birthday;
        this.address = address;
        this.createDate = createDate;
        this.updateDate = updateDate;
        this.lastLoginDate = lastLoginDate;
        this.disabled = disabled;
        this.phone = phone;
        this.isPhoneActive = isPhoneActive;
        this.email = email;
        this.isEmailActive = isEmailActive;
        this.language = language;
        this.city = city;
        this.province = province;
        this.country = country;
    }

    public XbUser() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId == null ? null : appId.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName == null ? null : realName.trim();
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName == null ? null : nickName.trim();
    }

    public Boolean getGender() {
        return gender;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl == null ? null : avatarUrl.trim();
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature == null ? null : signature.trim();
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId == null ? null : openId.trim();
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId == null ? null : unionId.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Boolean getIsPhoneActive() {
        return isPhoneActive;
    }

    public void setIsPhoneActive(Boolean isPhoneActive) {
        this.isPhoneActive = isPhoneActive;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public Boolean getIsEmailActive() {
        return isEmailActive;
    }

    public void setIsEmailActive(Boolean isEmailActive) {
        this.isEmailActive = isEmailActive;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language == null ? null : language.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country == null ? null : country.trim();
    }
}