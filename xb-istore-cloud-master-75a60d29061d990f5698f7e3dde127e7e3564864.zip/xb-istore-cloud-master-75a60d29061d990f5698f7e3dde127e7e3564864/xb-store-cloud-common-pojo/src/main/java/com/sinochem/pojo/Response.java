package com.sinochem.pojo;

public class Response {
    private Integer errorCode;
    private Object data;
    private String msg;

    public Response(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Response(Integer errorCode, String msg) {
        this.errorCode = errorCode;
        this.msg = msg;
    }

    public Response(Object data){
        this.errorCode=0;
        this.data = data;
        this.msg = "";
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
