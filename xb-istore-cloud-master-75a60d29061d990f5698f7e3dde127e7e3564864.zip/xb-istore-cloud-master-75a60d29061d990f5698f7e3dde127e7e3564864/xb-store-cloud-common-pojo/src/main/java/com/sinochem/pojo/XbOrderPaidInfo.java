package com.sinochem.pojo;

import java.util.Date;

public class XbOrderPaidInfo {
    private Long id;

    private String appid;

    private String attach;

    private String bankType;

    private String cashFee;

    private String deviceInfo;

    private String feeType;

    private String isSubscribe;

    private String mchId;

    private String nonceStr;

    private String openid;

    private String outTradeNo;

    private String resultCode;

    private String returnCode;

    private String sign;

    private String timeEnd;

    private String totalFee;

    private String tradeType;

    private String transactionId;

    private Date createDate;

    public XbOrderPaidInfo(Long id, String appid, String attach, String bankType, String cashFee, String deviceInfo, String feeType, String isSubscribe, String mchId, String nonceStr, String openid, String outTradeNo, String resultCode, String returnCode, String sign, String timeEnd, String totalFee, String tradeType, String transactionId, Date createDate) {
        this.id = id;
        this.appid = appid;
        this.attach = attach;
        this.bankType = bankType;
        this.cashFee = cashFee;
        this.deviceInfo = deviceInfo;
        this.feeType = feeType;
        this.isSubscribe = isSubscribe;
        this.mchId = mchId;
        this.nonceStr = nonceStr;
        this.openid = openid;
        this.outTradeNo = outTradeNo;
        this.resultCode = resultCode;
        this.returnCode = returnCode;
        this.sign = sign;
        this.timeEnd = timeEnd;
        this.totalFee = totalFee;
        this.tradeType = tradeType;
        this.transactionId = transactionId;
        this.createDate = createDate;
    }

    public XbOrderPaidInfo() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid == null ? null : appid.trim();
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach == null ? null : attach.trim();
    }

    public String getBankType() {
        return bankType;
    }

    public void setBankType(String bankType) {
        this.bankType = bankType == null ? null : bankType.trim();
    }

    public String getCashFee() {
        return cashFee;
    }

    public void setCashFee(String cashFee) {
        this.cashFee = cashFee == null ? null : cashFee.trim();
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo == null ? null : deviceInfo.trim();
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType == null ? null : feeType.trim();
    }

    public String getIsSubscribe() {
        return isSubscribe;
    }

    public void setIsSubscribe(String isSubscribe) {
        this.isSubscribe = isSubscribe == null ? null : isSubscribe.trim();
    }

    public String getMchId() {
        return mchId;
    }

    public void setMchId(String mchId) {
        this.mchId = mchId == null ? null : mchId.trim();
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr == null ? null : nonceStr.trim();
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid == null ? null : openid.trim();
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo == null ? null : outTradeNo.trim();
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode == null ? null : resultCode.trim();
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode == null ? null : returnCode.trim();
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign == null ? null : sign.trim();
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd == null ? null : timeEnd.trim();
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee == null ? null : totalFee.trim();
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType == null ? null : tradeType.trim();
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId == null ? null : transactionId.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}