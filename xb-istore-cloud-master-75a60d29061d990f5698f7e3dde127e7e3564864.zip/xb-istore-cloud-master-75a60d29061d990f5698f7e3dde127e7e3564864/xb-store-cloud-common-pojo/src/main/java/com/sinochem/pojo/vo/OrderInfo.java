package com.sinochem.pojo.vo;

import com.sinochem.pojo.XbOrder;
import com.sinochem.pojo.XbOrderDetail;
import com.sinochem.pojo.XbShop;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @description: vo层订单实体
 * @author: liuyuanzhi
 * @create 2018-03-12 下午6:26
 **/
public class OrderInfo {
    //订单编号
    private String orderNo;
    //店铺编号
    private Long shopNo;
    //店铺名称
    private String shopName;
    //订单状态
    private Byte orderStatus;
    //订单总量
    private Integer goodsCount;
    //应付金额
    private BigDecimal goodsAmountTotal;
    //实付金额
    private BigDecimal orderAmountTotal;
    //折扣金额
    private BigDecimal discAmountTotal;
    //支付渠道
    private Byte payChannel;
    //下单时间
    private String createTime;
    //支付时间
    private String payTime;
    //验货状态
    private Boolean tradeDone;
    //备注
    private String remark;
    //订单明细
    private List<Detail> orderDetailList;

    public OrderInfo(XbOrder order){
        if(order!=null){
            orderNo = order.getOrderNo();
            shopNo = order.getShopNo();
            orderStatus = order.getOrderStatus();
            goodsCount = order.getGoodsCount();
            goodsAmountTotal = order.getGoodsAmountTotal();
            orderAmountTotal = order.getOrderAmountTotal();
            discAmountTotal = order.getDiscAmountTotal();
            payChannel = order.getPayChannel();
            tradeDone = order.getTradeDone();
            remark = order.getRemark();
            Date createDate = order.getCreateTime();
            if(createDate==null){
                createTime = "0";
            } else {
                createTime = createDate.getTime()+"";
            }
            Date pay = order.getPayTime();
            if(pay!=null){
                payTime = order.getPayTime().getTime()+"";
            } else {
                payTime = "0";//兼容商家端,TODO 后续商家端需要自行处理
            }
            List<Detail> detailList = new ArrayList<>();
            if(order.getOrderDetailList()!=null){
                for(XbOrderDetail detail: order.getOrderDetailList()){
                    detailList.add(new Detail(detail));
                }
            }
            orderDetailList = detailList;
            XbShop shop = order.getShop();
            if(shop!=null){
                shopName = shop.getShopName();
            }
        }
    }

    public OrderInfo(){

    }

    public static class Detail {
        public Detail(){

        }
        public Detail(XbOrderDetail orderDetail){
            orderNo = orderDetail.getOrderNo();
            goodsName = orderDetail.getGoodsName();
            salePrice = orderDetail.getSalePrice();
            categoryType = orderDetail.getCategoryType();
            brandName = orderDetail.getBrandName();
            shortGoodsName = orderDetail.getShortGoodsName();
            sapStock = orderDetail.getSapStock();
            saleDepartment = orderDetail.getSaleDepartment();
            picUrl = orderDetail.getPicUrl();
            originPlace = orderDetail.getOriginPlace();
            goodsCountD = orderDetail.getGoodsCountD();
            goodsAmount = orderDetail.getGoodsAmount();
            remarkD = orderDetail.getRemarkD();
        }
        private String orderNo;
        //商品编号
        //private Long goodsCode;
        //商品名称
        private String goodsName;
        //商品售价
        private BigDecimal salePrice;
        //商品类型
        private Byte categoryType;
        //品牌名称
        private String brandName;
        //商品简称
        private String shortGoodsName;
        //sap物料编号
        private String sapStock;
        //销售部门
        private String saleDepartment;
        //商品图片
        private String picUrl;
        //原产地
        private String originPlace;
        //订购数量
        private Integer goodsCountD;
        //订购金额
        private BigDecimal goodsAmount;
        //备注
        private String remarkD;

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        /*public Long getGoodsCode() {
            return goodsCode;
        }

        public void setGoodsCode(Long goodsCode) {
            this.goodsCode = goodsCode;
        }*/

        public String getGoodsName() {
            return goodsName;
        }

        public void setGoodsName(String goodsName) {
            this.goodsName = goodsName;
        }

        public BigDecimal getSalePrice() {
            return salePrice;
        }

        public void setSalePrice(BigDecimal salePrice) {
            this.salePrice = salePrice;
        }

        public Byte getCategoryType() {
            return categoryType;
        }

        public void setCategoryType(Byte categoryType) {
            this.categoryType = categoryType;
        }

        public String getBrandName() {
            return brandName;
        }

        public void setBrandName(String brandName) {
            this.brandName = brandName;
        }

        public String getShortGoodsName() {
            return shortGoodsName;
        }

        public void setShortGoodsName(String shortGoodsName) {
            this.shortGoodsName = shortGoodsName;
        }

        public String getSapStock() {
            return sapStock;
        }

        public void setSapStock(String sapStock) {
            this.sapStock = sapStock;
        }

        public String getSaleDepartment() {
            return saleDepartment;
        }

        public void setSaleDepartment(String saleDepartment) {
            this.saleDepartment = saleDepartment;
        }

        public String getPicUrl() {
            return picUrl;
        }

        public void setPicUrl(String picUrl) {
            this.picUrl = picUrl;
        }

        public String getOriginPlace() {
            return originPlace;
        }

        public void setOriginPlace(String originPlace) {
            this.originPlace = originPlace;
        }

        public Integer getGoodsCountD() {
            return goodsCountD;
        }

        public void setGoodsCountD(Integer goodsCountD) {
            this.goodsCountD = goodsCountD;
        }

        public BigDecimal getGoodsAmount() {
            return goodsAmount;
        }

        public void setGoodsAmount(BigDecimal goodsAmount) {
            this.goodsAmount = goodsAmount;
        }

        public String getRemarkD() {
            return remarkD;
        }

        public void setRemarkD(String remarkD) {
            this.remarkD = remarkD;
        }
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Long getShopNo() {
        return shopNo;
    }

    public void setShopNo(Long shopNo) {
        this.shopNo = shopNo;
    }

    public Byte getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Byte orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(Integer goodsCount) {
        this.goodsCount = goodsCount;
    }

    public BigDecimal getGoodsAmountTotal() {
        return goodsAmountTotal;
    }

    public void setGoodsAmountTotal(BigDecimal goodsAmountTotal) {
        this.goodsAmountTotal = goodsAmountTotal;
    }

    public BigDecimal getOrderAmountTotal() {
        return orderAmountTotal;
    }

    public void setOrderAmountTotal(BigDecimal orderAmountTotal) {
        this.orderAmountTotal = orderAmountTotal;
    }

    public BigDecimal getDiscAmountTotal() {
        return discAmountTotal;
    }

    public void setDiscAmountTotal(BigDecimal discAmountTotal) {
        this.discAmountTotal = discAmountTotal;
    }

    public Byte getPayChannel() {
        return payChannel;
    }

    public void setPayChannel(Byte payChannel) {
        this.payChannel = payChannel;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public Boolean getTradeDone() {
        return tradeDone;
    }

    public void setTradeDone(Boolean tradeDone) {
        this.tradeDone = tradeDone;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<Detail> getOrderDetailList() {
        return orderDetailList;
    }

    public void setOrderDetailList(List<Detail> orderDetailList) {
        this.orderDetailList = orderDetailList;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
}
