package com.sinochem.pojo.vo;

/**
 * @description:
 * @author: liuyuanzhi
 * @create 2018-03-26 下午8:06
 **/
public class UserBean {
    private Integer id;
    private String username;
    private String phone;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
