package com.sinochem.pojo.vo;

import com.sinochem.pojo.XbGoods;
import com.sinochem.pojo.XbGoodsDept;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

/**
 * @description: 商品信息vo实体
 * @author: liuyuanzhi
 * @create 2018-03-12 下午2:30
 **/
public class Goods {
    //条形码
    private Long barCode;
    //售价
    private BigDecimal salePrice;
    //是否可退标识
    private Byte returnMark;
    //是否可售
    private Byte saleMark;
    //状态
    private Byte status;
    //库存
    private Long stock;
    //图片
    private String picUrl;
    //名称
    private String goodsName;
    //名称-简称
    private String shortGoodsName;
    //类别
    private Byte categoryType;
    //品牌
    private String brandName;
    //产地
    private String originPlace;
    //店铺编号
    private Long shopNo;
    //产品编码
    private Long goodsCode;

    public Goods(){

    }

    /**
     * 实体转换
     * @param goodsDept
     */
    public Goods(XbGoodsDept goodsDept){
        XbGoods goods = null;
        if(goodsDept!=null){
            barCode=goodsDept.getBarCode();
            salePrice=goodsDept.getSalePrice();
            returnMark  = goodsDept.getReturnMark();
            saleMark = goodsDept.getSaleMark();
            status = goodsDept.getStatus();
            stock = goodsDept.getStock();
            picUrl = goodsDept.getPicUrl();
            shopNo = goodsDept.getShopNo();
            goods = goodsDept.getXbGoods();
            goodsCode = goodsDept.getGoodsCode();
        }
        if(goods!=null){
            goodsName = goods.getGoodsName();
            shortGoodsName = goods.getShortGoodsName();
            categoryType = goods.getCategoryType();
            brandName = goods.getBrandName();
            originPlace = goods.getOriginPlace();
            if(StringUtils.isEmpty(picUrl)){
                picUrl = goods.getMainPicUrl();
            }
        }
    }

    public Long getBarCode() {
        return barCode;
    }

    public void setBarCode(Long barCode) {
        this.barCode = barCode;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public Byte getReturnMark() {
        return returnMark;
    }

    public void setReturnMark(Byte returnMark) {
        this.returnMark = returnMark;
    }

    public Byte getSaleMark() {
        return saleMark;
    }

    public void setSaleMark(Byte saleMark) {
        this.saleMark = saleMark;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Long getStock() {
        return stock;
    }

    public void setStock(Long stock) {
        this.stock = stock;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getShortGoodsName() {
        return shortGoodsName;
    }

    public void setShortGoodsName(String shortGoodsName) {
        this.shortGoodsName = shortGoodsName;
    }

    public Byte getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(Byte categoryType) {
        this.categoryType = categoryType;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getOriginPlace() {
        return originPlace;
    }

    public void setOriginPlace(String originPlace) {
        this.originPlace = originPlace;
    }

    public Long getShopNo() {
        return shopNo;
    }

    public void setShopNo(Long shopNo) {
        this.shopNo = shopNo;
    }

    public Long getGoodsCode() {
        return goodsCode;
    }

    public void setGoodsCode(Long goodsCode) {
        this.goodsCode = goodsCode;
    }
}
