package com.sinochem.pojo.vo;

/**
 * @description: 订单查询实体
 * @author: liuyuanzhi
 * @create 2018-03-20 下午4:35
 **/
public class OrderRequest {
    //支付订单起始时间
    private String createStartDate;
    //支付订单结束时间
    private String createEndDate;
    //店铺编号
    private Long shopNo;
    //验货状态
    private Integer tradeDone;
    //page
    private Integer page;
    //pageSize
    private Integer pageSize;

    //token
    private String token="Hans";

    public String getCreateStartDate() {
        return createStartDate;
    }

    public void setCreateStartDate(String createStartDate) {
        this.createStartDate = createStartDate;
    }

    public String getCreateEndDate() {
        return createEndDate;
    }

    public void setCreateEndDate(String createEndDate) {
        this.createEndDate = createEndDate;
    }

    public Long getShopNo() {
        return shopNo;
    }

    public void setShopNo(Long shopNo) {
        this.shopNo = shopNo;
    }

    public Integer getTradeDone() {
        return tradeDone;
    }

    public void setTradeDone(Integer tradeDone) {
        this.tradeDone = tradeDone;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
