package com.sinochem.pojo.vo;

/**
 * @description: 账号请求实体
 * @author: liuyuanzhi
 * @create 2018-03-21 下午8:56
 **/
public class UserRequest {
    private String userName;
    private String passWord;
    private String token;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
