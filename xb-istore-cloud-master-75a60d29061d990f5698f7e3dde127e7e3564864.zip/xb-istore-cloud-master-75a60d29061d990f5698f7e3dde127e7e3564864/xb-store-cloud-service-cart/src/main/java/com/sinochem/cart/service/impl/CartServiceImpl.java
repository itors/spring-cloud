package com.sinochem.cart.service.impl;

import com.sinochem.cart.service.CartService;
import com.sinochem.mapper.XbGoodsMapper;
import com.sinochem.pojo.XbCartInfo;
import com.sinochem.pojo.XbGoods;
import com.sinochem.pojo.XbGoodsExample;
import com.sinochem.pojo.XbResult;
import com.sinochem.utils.FastJsonConvert;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 购物车操作实现
 *
 * @author liuming
 * @create
 */
@Api(value = "API - CartServiceImpl", description = "购物车操作")
@RestController
@RefreshScope
public class CartServiceImpl implements CartService {

    private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    @Value("${redisKey.prefix.cart_info_profix}")
    private String CART_INFO_PROFIX;
    @Value("${redisKey.prefix.redis_cart_expire_time}")
    private Integer REDIS_CART_EXPIRE_TIME;
    @Value("${redisKey.prefix.goods_info_profix}")
    private String GOODS_INFO_PROFIX;
    @Value("${redisKey.prefix.goods_info_base_suffix}")
    private String GOODS_INFO_BASE_SUFFIX;

    @Autowired
    private RedissonClient redissonClient;

    @Autowired
    private XbGoodsMapper xbGoodsMapper;

    @Override
    @ApiOperation("购物车添加商品")
    //@ApiImplicitParams(
    //        {
    //                @ApiImplicitParam(name = "goodsCode", value = "", required = true, dataType = "Long"),
    //                @ApiImplicitParam(name = "goodsCount", value = "", required = true, dataType = "Integer"),
    //                @ApiImplicitParam(name = "openId", value = "", required = true, dataType = "String"),
    //        }
    //)
    @ApiResponses(
            {
                    @ApiResponse(code = 200, message = "Successful — 请求已完成"),
                    @ApiResponse(code = 400, message = "请求中有语法问题，或不能满足请求"),
                    @ApiResponse(code = 401, message = "未授权客户机访问数据"),
                    @ApiResponse(code = 404, message = "服务器找不到给定的资源；文档不存在"),
                    @ApiResponse(code = 500, message = "服务器不能完成请求")
            }
    )
    public XbResult addCart(Long goodsCode, Integer goodsCount, String openId) {

        String key = CART_INFO_PROFIX + openId;
        String cartInfoString = null;
        try {
            RBucket<String> cartInfoBucket = redissonClient.getBucket(key);
            cartInfoString = cartInfoBucket.get();
        } catch (Exception e) {
            logger.error("Redis出错!", e);
        }

        XbGoods goods = null;

        String redisGoods = null;
        try {
            RBucket<String> goodsBucket = redissonClient.getBucket(GOODS_INFO_PROFIX + goodsCode + GOODS_INFO_BASE_SUFFIX);
            redisGoods = goodsBucket.get();
        } catch (Exception e) {
            logger.error("Redis error", e);
        }

        if (StringUtils.isNotBlank(redisGoods)) {
            goods = FastJsonConvert.convertJSONToObject(redisGoods, XbGoods.class);

        } else {
            XbGoodsExample example = new XbGoodsExample();
            XbGoodsExample.Criteria criteria = example.createCriteria();

            criteria.andGoodsCodeEqualTo(goodsCode);

            List<XbGoods> goodsList = null;

            try {
                goodsList = xbGoodsMapper.selectByExample(example);
            } catch (Exception e) {
                logger.error("select DB error", e);
            }

            if (goodsList != null && goodsList.size() > 0) {
                goods = goodsList.get(0);
            } else {
                return XbResult.build(400, 40008,"商品查询不到!");
            }
        }

        XbCartInfo xbCartInfo = new XbCartInfo();

        xbCartInfo.setCount(goodsCount);
        //xbCartInfo.setPicUrl(goods.getPicUrl());
        //xbCartInfo.setGoodsCode(goods.getGoodsCode());
        //xbCartInfo.setGoodsName(goods.getGoodsName());
        //xbCartInfo.setSalePrice(goods.getSalePrice());
        //小计
        //xbCartInfo.setSum(goods.getSalePrice().multiply(BigDecimal.valueOf(goodsCount)));
        //XbCartInfo.setId(goods.getId());
        //XbCartInfo.setName(goods.getTitle());
        //String[] split = goods.getImage().split(",");
        //XbCartInfo.setImageUrl(split[0]);
        //XbCartInfo.setColour("黑色");
        //XbCartInfo.setNum(pcount);
        //XbCartInfo.setPrice(goods.getPrice());
        //XbCartInfo.setSize("32GB");

        if (StringUtils.isBlank(cartInfoString)) {

            ArrayList<XbCartInfo> cartInfoList = new ArrayList<>();

            cartInfoList.add(xbCartInfo);

            logger.debug("第一次保存商品到Redis openId:" + openId);

            try {
                RBucket<String> bucket = redissonClient.getBucket(key);
                bucket.set(FastJsonConvert.convertObjectToJSON(cartInfoList), REDIS_CART_EXPIRE_TIME, TimeUnit.SECONDS);
            } catch (Exception e) {
                logger.error("Redis error", e);
            }

            return XbResult.build(0,200, "ok", xbCartInfo);

        } else {
            List<XbCartInfo> list = FastJsonConvert.convertJSONToArray(cartInfoString, XbCartInfo.class);
            if (list != null && list.size() > 0) {
                boolean flag = true;
                for (int i = 0; i < list.size(); i++) {
                    XbCartInfo Info = list.get(i);
                    if (Info.getGoodsCode().equals(goods.getGoodsCode())) {
                        Info.setCount(Info.getCount() + goodsCount);
                        list.remove(i);
                        list.add(Info);
                        flag = false;

                        logger.debug("商品已经存在数量加" + goodsCount + "个 openId:" + openId);
                    }
                }
                if (flag) {
                    list.add(xbCartInfo);
                    logger.debug("商品不存在数量为" + goodsCount + "个 openId:" + openId);
                }
            }

            logger.debug("商品添加完成 购物车" + list.size() + "件商品 openId:" + openId);

            try {
                RBucket<String> bucket = redissonClient.getBucket(key);
                bucket.set(FastJsonConvert.convertObjectToJSON(list), REDIS_CART_EXPIRE_TIME, TimeUnit.SECONDS);
            } catch (Exception e) {
                logger.error("Redis出错!", e);
            }

            return XbResult.build(0,200, "ok", xbCartInfo);
        }
    }

    @Override
    @ApiOperation("获取商品信息")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(name = "cookieOpenId", value = "", required = true, dataType = "Long"),
            }
    )
    @ApiResponses(
            {
                    @ApiResponse(code = 200, message = "Successful — 请求已完成"),
                    @ApiResponse(code = 400, message = "请求中有语法问题，或不能满足请求"),
                    @ApiResponse(code = 401, message = "未授权客户机访问数据"),
                    @ApiResponse(code = 404, message = "服务器找不到给定的资源；文档不存在"),
                    @ApiResponse(code = 500, message = "服务器不能完成请求")
            }
    )
    public List<XbCartInfo> getCartInfoListByCookiesId(String cookieOpenId) {
        RBucket<String> cartInfoBucket = redissonClient.getBucket(CART_INFO_PROFIX + cookieOpenId);
        String cartInfoString = cartInfoBucket.get();

        if (StringUtils.isNotBlank(cartInfoString)) {
            List<XbCartInfo> cartInfoList = FastJsonConvert.convertJSONToArray(cartInfoString, XbCartInfo.class);

            return cartInfoList;
        }

        return null;
    }

    /**
     * 根据商品id和数量对购物车增加商品或减少商品
     *
     * @param goodsCode    商品id
     * @param goodsCount 增加数量
     * @param type       1 增加 2 减少
     * @param index      商品位置   ps:用于直接定位商品 不用遍历整个购物车
     * @return
     */
    @Override
    @ApiOperation("获取商品信息")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(name = "goodsCode", value = "", required = true, dataType = "Long"),
                    @ApiImplicitParam(name = "goodsCount", value = "", required = true, dataType = "Integer"),
                    @ApiImplicitParam(name = "type", value = "", required = true, dataType = "Integer"),
                    @ApiImplicitParam(name = "index", value = "", required = true, dataType = "Integer"),
                    @ApiImplicitParam(name = "cookieOpenId", value = "", required = true, dataType = "String"),
            }
    )
    @ApiResponses(
            {
                    @ApiResponse(code = 200, message = "Successful — 请求已完成"),
                    @ApiResponse(code = 400, message = "请求中有语法问题，或不能满足请求"),
                    @ApiResponse(code = 401, message = "未授权客户机访问数据"),
                    @ApiResponse(code = 404, message = "服务器找不到给定的资源；文档不存在"),
                    @ApiResponse(code = 500, message = "服务器不能完成请求")
            }
    )
    public XbResult decreOrIncre(Long goodsCode, Integer goodsCount, Integer type, Integer index, String cookieOpenId) {

        String key = CART_INFO_PROFIX + cookieOpenId;

        List<XbCartInfo> cartInfoList = getCartInfoListByCookiesId(cookieOpenId);
        if (cartInfoList == null || cartInfoList.size() == 0) {
            return XbResult.build(400,40008, "购物车没有商品!");
        }

        XbCartInfo XbCartInfo = cartInfoList.get(index);

        if (type == 1) {
            XbCartInfo.setCount(XbCartInfo.getCount() + goodsCount);
        } else {
            XbCartInfo.setCount(XbCartInfo.getCount() - goodsCount);
        }
        //cartInfoList.remove(index);
        //cartInfoList.add(index, XbCartInfo);

        RBucket<String> bucket = redissonClient.getBucket(key);
        bucket.set(FastJsonConvert.convertObjectToJSON(cartInfoList), REDIS_CART_EXPIRE_TIME, TimeUnit.SECONDS);

        return XbResult.ok();
    }

}
