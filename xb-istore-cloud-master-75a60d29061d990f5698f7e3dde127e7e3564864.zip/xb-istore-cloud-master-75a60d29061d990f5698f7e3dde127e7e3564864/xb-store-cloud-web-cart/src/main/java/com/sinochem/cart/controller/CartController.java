package com.sinochem.cart.controller;

import com.sinochem.cart.service.CartService;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 购物车 Controller
 *
 * @author liuming
 * @create
 */

@Api(value = "API - CartController", description = "购物车 Controller")
@Controller
@RefreshScope
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private CartService cartService;

    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public String addCart(@RequestParam("goodsCode") Long goodsCode,
                          @RequestParam("goodsCount") Integer goodsCount,
                          @RequestParam("openId") String openId) {
        cartService.addCart( goodsCode, goodsCount, openId);
        return "success";
    }

}
