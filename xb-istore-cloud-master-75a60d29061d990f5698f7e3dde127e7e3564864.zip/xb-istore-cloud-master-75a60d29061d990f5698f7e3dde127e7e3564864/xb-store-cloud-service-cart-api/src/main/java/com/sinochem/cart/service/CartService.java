package com.sinochem.cart.service;


import com.sinochem.cart.service.hystrix.CartServiceHystrix;
import com.sinochem.pojo.XbCartInfo;
import com.sinochem.pojo.XbResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * 购物车相关操作 Service
 *
 * @author liuming
 * @create
 */

@FeignClient(value = "xb-store-cloud-service-cart", fallback = CartServiceHystrix.class)
public interface CartService {

    @RequestMapping(value = "/addCart", method = RequestMethod.POST)
    XbResult addCart(
            @RequestParam("goodsCode") Long goodsCode,
            @RequestParam("goodsCount") Integer goodsCount,
            @RequestParam("openId") String openId
    );

    @RequestMapping(value = "/getCartInfoListByCookiesId", method = RequestMethod.POST)
    List<XbCartInfo> getCartInfoListByCookiesId(@RequestParam("cookieOpenId") String cookieOpenId);

    /**
     * 根据商品id和数量对购物车增加商品或减少商品
     *
     * @param goodsCode    商品id
     * @param goodsCount 增加数量
     * @param type       1 增加 2 减少
     * @param index      商品位置   ps:用于直接定位商品 不用遍历整个购物车
     * @return
     */
    @RequestMapping(value = "/decreOrIncre", method = RequestMethod.POST)
    XbResult decreOrIncre(
            @RequestParam("goodsCode") Long goodsCode,
            @RequestParam("goodsCount") Integer goodsCount,
            @RequestParam("type") Integer type,
            @RequestParam("index") Integer index,
            @RequestParam("cookieUUID") String cookieOpenId
    );


}
