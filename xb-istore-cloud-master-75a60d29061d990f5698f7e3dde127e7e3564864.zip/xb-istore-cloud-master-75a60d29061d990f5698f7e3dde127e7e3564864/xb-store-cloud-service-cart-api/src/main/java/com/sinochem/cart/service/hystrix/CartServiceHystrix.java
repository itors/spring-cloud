package com.sinochem.cart.service.hystrix;

import com.sinochem.cart.service.CartService;
import com.sinochem.pojo.XbCartInfo;
import com.sinochem.pojo.XbResult;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 购物车服务 熔断处理
 *
 * @author liuming
 * @create
 */

@Component
public class CartServiceHystrix implements CartService {


    @Override
    public XbResult addCart(Long goodsCode, Integer goodsCount, String openId) {
        return null;
    }

    @Override
    public List<XbCartInfo> getCartInfoListByCookiesId(String cookieOpenId) {
        return null;
    }

    @Override
    public XbResult decreOrIncre(Long goodsCode, Integer goodsCount, Integer type, Integer index, String cookieOpenId) {
        return null;
    }
}
